Test scripts from the build conversation (reference copies, not yet ready to run from the repository)
=====================================================================================================
These were used in a temporary workspace and read files from fixed /tmp paths, so they need small changes
before they will run from a repo folder (for example sql/tests/ and app/tests/).

database/   Tests run on a local PostgreSQL 16 with a stand-in for Supabase's auth layer.
  stub.sql          creates the stand-in roles, auth.users and auth.uid()
  rebuild.sh        rebuilds a test database from the SQL files and runs perm_test.py
  perm_test.py      97 permission checks: owner, admin, editor, viewer, outsider, ownership transfer
  v5_test.py        last-used setlist column
  v6_test.py        band deletion purges its history
  v7_test.py        band logo limits and permissions
  v8_test.py        band link ending: who can set it, uniqueness, allowed characters, reserved words
app/        Screen and sync logic tests (Node), built by pulling code out of index.html with the gen_*.py scripts.
  sync_test.mjs     the offline sync engine run against real Postgres with row-level security
edge-function/  Tests of lookup-song.ts using simulated GetSongBPM and Song Finder answers (Node and esbuild).

Rules worth keeping: a permission change needs a test that was run; weaken a rule on purpose and confirm a test fails.
