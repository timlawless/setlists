import { transformSync } from 'esbuild';
import fs from 'fs';
const ts = fs.readFileSync('/home/claude/v17-update/lookup-song.ts', 'utf8').replace("import { createClient } from 'jsr:@supabase/supabase-js@2';", 'const createClient = globalThis.__createClient;');
const js = transformSync(ts, { loader: 'ts', format: 'esm', target: 'es2022' }).code;
fs.writeFileSync('/tmp/fn/lookup.mjs', js);
console.log('TypeScript transformed OK (' + js.length + ' bytes)');
