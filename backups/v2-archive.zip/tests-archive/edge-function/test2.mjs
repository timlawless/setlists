let handler = null; let env = {}; let signedIn = true; const calls = [];
globalThis.Deno = { serve: (h) => { handler = h; }, env: { get: (k) => env[k] } };
globalThis.__createClient = () => ({ auth: { getUser: async () => (signedIn ? { data: { user: { id: 'u' } }, error: null } : { data: {}, error: new Error('no') }) } });
globalThis.setTimeout = (f) => { f(); return 0; }; globalThis.clearTimeout = () => {};
let routes = [];
globalThis.fetch = async (url, opts) => {
  calls.push({ url: String(url), headers: opts?.headers || {} });
  for (const [m, r] of routes) if (m(String(url))) { const v = await r(String(url)); return { status: v.status ?? 200, json: async () => { if (v.notJson) throw new Error('x'); return v.body; } }; }
  return { status: 404, json: async () => ({}) };
};
await import('/tmp/fn/lookup.mjs');
function fail(m) { console.log('FAIL:', m); process.exit(1); } const ok = (c, m) => { if (!c) fail(m); };
const call = async (body, method = 'POST', auth = 'Bearer tok') => { const r = await handler(new Request('https://x/f', { method, headers: { Authorization: auth, 'content-type': 'application/json' }, body: method === 'POST' ? JSON.stringify(body) : undefined })); return { status: r.status, body: await r.json().catch(() => null), headers: r.headers }; };
const sfSearch = (u) => u.includes('songfinder.dev/api/track/search'); const sfDetail = (u) => u.includes('songfinder.dev/api/track/detail');
const env0 = () => { env = {}; calls.length = 0; routes = []; signedIn = true; };
const DET = (isrc, title, artist, tempo, cross, key) => ({ body: { code: 0, data: { track: { isrc, title, artist }, features: { tempo, key: key ? { name: key } : undefined }, tempoCrossCheck: cross } } });

// basics
env0(); let r = await call({}, 'OPTIONS'); ok(r.status === 200, 'preflight'); r = await call({}, 'GET'); ok(r.status === 405, 'POST only');
signedIn = false; r = await call({ title: 'x' }); ok(r.status === 401, 'sign in'); signedIn = true; r = await call({ title: ' ' }); ok(r.status === 400, 'title');

// the I Gotta Feeling case: many recordings share the title
const FOUND = [
  { isrc: 'USAAA0000001', title: 'I Gotta Feeling', artist: 'The Wanderers', album: 'Old Roads', releaseYear: 1969 },
  { isrc: 'USAAA0000002', title: 'I Gotta Feeling (Karaoke Version)', artist: 'Sing King', album: 'Karaoke Hits' },
  { isrc: 'USAAA0000003', title: 'I Gotta Feeling Tonight', artist: 'Some Band', album: 'Nights' },
  { isrc: 'USUM70905601', title: 'I Gotta Feeling', artist: 'Black Eyed Peas', album: 'The E.N.D.', releaseYear: 2009 },
  { isrc: 'USAAA0000004', title: 'I Gotta Feeling (Tribute to Black Eyed Peas)', artist: 'Party Starters', album: 'Tribute Hits' },
  { isrc: 'USUM70905602', title: 'I Gotta Feeling', artist: 'Black Eyed Peas', album: 'The E.N.D. (Deluxe)', releaseYear: 2009 }, // same song again
  { isrc: 'BAD', title: 'Broken', artist: 'x' },
  { isrc: 'USAAA0000005', title: 'I Gotta Feeling', artist: 'Lullaby Orchestra', album: 'Lullaby Versions' },
  { isrc: 'USAAA0000006', title: 'Gotta Feeling', artist: 'Another', album: 'A' }, { isrc: 'USAAA0000007', title: 'Feeling', artist: 'Z', album: 'Z' },
  { isrc: 'USAAA0000008', title: 'Another Gotta Feeling', artist: 'Y', album: 'Y' }, { isrc: 'USAAA0000009', title: 'I Gotta Feeling Again', artist: 'Q', album: 'Q' } ];
env0(); routes.push([sfSearch, () => ({ body: { code: 0, data: FOUND } })]);
r = await call({ title: 'I Gotta Feeling', artist: 'Black Eyed Peas' });
let cs = r.body.candidates; ok(r.status === 200 && r.body.source === 'Song Finder' && r.body.results.length === 0, 'search returns candidates only: ' + JSON.stringify(r.body).slice(0, 200));
ok(cs[0].artist === 'Black Eyed Peas' && cs[0].exact === true && cs[0].id === 'sf:USUM70905601' && cs[0].year === '2009' && cs[0].album === 'The E.N.D.', 'with the artist typed the right recording is first: ' + JSON.stringify(cs[0]));
ok(cs.filter((c) => c.artist === 'Black Eyed Peas').length === 1, 'the duplicate recording is listed once');
ok(!cs.some((c) => c.id === 'sf:BAD'), 'invalid ids dropped'); ok(cs.length <= 8, 'at most eight');
const idx = (artist) => cs.findIndex((c) => c.artist === artist);
const sinks = (a, b) => idx(a) === -1 || idx(a) > idx(b); // pushed off the end of the list counts as sunk
ok(sinks('Sing King', 'The Wanderers') && sinks('Party Starters', 'The Wanderers') && idx('Lullaby Orchestra') > idx('Some Band'), 'karaoke, tribute and lullaby versions sink: ' + cs.map((c) => c.artist).join(' | '));
ok(idx('Sing King') === -1 || idx('Sing King') > idx('Black Eyed Peas'), 'karaoke never beats the real recording');
ok(calls.length === 1 && sfSearch(calls[0].url), 'step 1 makes a single call, no analysis yet');
// without the artist: exact titles come before near titles, noise last
env0(); routes.push([sfSearch, () => ({ body: { code: 0, data: FOUND } })]); r = await call({ title: 'I Gotta Feeling' }); cs = r.body.candidates;
const exactFirst = cs.findIndex((c) => !c.exact); ok(cs.slice(0, exactFirst).every((c) => c.exact) && cs[0].exact, 'exact titles first');
ok(cs.some((c) => c.artist === 'Black Eyed Peas'), 'the well-known recording is on the list so it can be picked');
// an artist that matches nothing still returns the list, ranked by title
env0(); routes.push([sfSearch, () => ({ body: { code: 0, data: FOUND } })]); r = await call({ title: 'I Gotta Feeling', artist: 'Nobody Known' }); ok(r.body.candidates.length > 0, 'still lists candidates');
// cache: same search again, no new call
const n = calls.length; await call({ title: 'i gotta feeling', artist: 'nobody known' }); ok(calls.length === n, 'search cached');

// step 2: analyse one recording
const analyse = async (isrc, det) => { env0(); routes.push([sfDetail, () => det]); return call({ isrc }); };
r = await analyse('USUM70905601', DET('USUM70905601', 'I Gotta Feeling', 'Black Eyed Peas', 127.9, 128.2, 'E Minor'));
ok(r.status === 200 && r.body.results.length === 1, 'one match'); let m = r.body.results[0];
ok(m.tempo === 128 && m.key_of === 'Em' && m.confidence === 'high' && m.id === 'sf:USUM70905601' && m.time_sig === '' && m.artist === 'Black Eyed Peas' && !m.note, 'high confidence match ' + JSON.stringify(m));
ok(calls.length === 1 && calls[0].url.includes('isrc=USUM70905601'), 'one analysis call');
r = await analyse('sf:USUM70905612', DET('USUM70905612', 'T', 'A', 87, 174, 'B Minor')); m = r.body.results[0]; ok(m.confidence === 'check' && /174/.test(m.note) && m.key_of === 'Bm', 'prefixed id accepted; disagreement flagged');
r = await analyse('USUM70905613', DET('USUM70905613', 'T', 'A', 120, undefined, 'F# Major')); m = r.body.results[0]; ok(m.confidence === 'medium' && m.key_of === 'F#', 'single reading: medium');
r = await analyse('USUM70905614', { body: { code: 0, data: { track: {}, features: null } } }); ok(r.status === 200 && r.body.results.length === 0 && /No tempo/.test(r.body.note), 'no analysis: clear note, not an error');
r = await analyse('USUM70905615', { status: 429, body: {} }); ok(r.status === 502 && /busy/i.test(r.body.error), 'busy message');
env0(); let hits = 0; routes.push([sfDetail, () => (++hits === 1 ? { status: 429, body: {} } : DET('USUM70905616', 'T', 'A', 100, 100, 'C Major'))]); r = await call({ isrc: 'USUM70905616' }); ok(r.status === 200 && hits === 2, 'one retry after a 429');
env0(); r = await call({ isrc: 'not-an-isrc' }); ok(r.status === 400, 'invalid id refused'); ok(calls.length === 0, 'no call made for an invalid id');
r = await call({ isrc: '../../etc/passwd' }); ok(r.status === 400, 'path tricks refused');
// cache for analysis
env0(); routes.push([sfDetail, () => DET('USUM70905603', 'T', 'A', 100, 100, 'D Major')]); await call({ isrc: 'USUM70905603' }); const k = calls.length; await call({ isrc: 'USUM70905603' }); ok(calls.length === k, 'analysis cached');

// GetSongBPM unchanged
env0(); env.GETSONGBPM_API_KEY = 'k';
routes.push([(u) => u.includes('api.getsongbpm.com/search'), () => ({ body: { search: [{ song_id: 's1', song_title: 'Hard to Handle', artist: { name: 'Black Crowes' }, tempo: '96', time_sig: '4', key_of: 'A' }] } })]);
r = await call({ title: 'Hard to Handle', artist: 'Black Crowes' });
ok(r.body.source === 'GetSongBPM' && r.body.results[0].time_sig === '4/4' && r.body.candidates.length === 0 && calls.every((x) => x.headers['X-API-KEY'] === 'k' && !x.url.includes('songfinder')), 'GetSongBPM results used directly');
env0(); env.GETSONGBPM_API_KEY = 'bad'; routes.push([(u) => u.includes('api.getsongbpm.com'), () => ({ status: 403, body: {} })]); routes.push([sfSearch, () => ({ body: { code: 0, data: FOUND } })]);
r = await call({ title: 'I Gotta Feeling' }); ok(r.body.source === 'Song Finder' && r.body.candidates.length > 0, 'bad key falls back to the candidate list');
env0(); env.GETSONGBPM_API_KEY = 'k'; routes.push([(u) => u.includes('api.getsongbpm.com'), () => ({ body: { search: { error: 'no result' } } })]); routes.push([sfSearch, () => ({ body: { code: 0, data: FOUND } })]);
r = await call({ title: 'I Gotta Feeling' }); ok(r.body.source === 'Song Finder' && r.body.candidates.length > 0, 'empty result falls back');
// errors and encoding
env0(); routes.push([sfSearch, () => ({ status: 429, body: {} })]); r = await call({ title: 'Busy' }); ok(r.status === 502 && /busy/i.test(r.body.error), 'busy on search');
env0(); routes.push([sfSearch, () => ({ body: { code: 7, message: 'Bad query' } })]); r = await call({ title: 'E1' }); ok(r.status === 502 && r.body.error === 'Bad query', 'API message passed on');
env0(); routes.push([sfSearch, () => ({ body: { code: 0, data: [] } })]); r = await call({ title: 'a&b=c#d', artist: 'x y' }); ok(r.status === 200 && r.body.candidates.length === 0 && calls[0].url.includes('q=a%26b%3Dc%23d%20x%20y'), 'encoded, and an empty list is not an error');
ok(calls.every((x) => /SetlistApp/.test(x.headers['User-Agent'])), 'User-Agent sent');
console.log('lookup function (two-step) checks passed');
