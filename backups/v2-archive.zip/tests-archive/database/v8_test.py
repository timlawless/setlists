import psycopg2
U = {n: f'00000000-0000-0000-0000-00000000000{i}' for i, n in enumerate(['owner','admin','editor','viewer','outsider','legacy'], 1)}
conn = psycopg2.connect(dbname='t1', user='postgres', host='/var/run/postgresql'); conn.autocommit = True; cur = conn.cursor()
res=[]
def me(n): cur.execute('reset role'); cur.execute("select set_config('request.jwt.claim.sub',%s,false)",(U[n],)); cur.execute('set role authenticated')
def run(sql,a=None):
    try: cur.execute(sql,a); return ('ok',cur.rowcount)
    except psycopg2.Error as e: return ('err',type(e).__name__+': '+str(e).splitlines()[0])
def ok(l,c,d=''): res.append((l,c,d))
me('owner'); cur.execute("select id from public.create_band('Weaponized Conch')"); b1=cur.fetchone()[0]
me('outsider'); cur.execute("select id from public.create_band('Other Band')"); b2=cur.fetchone()[0]
cur.execute('reset role'); cur.execute("insert into public.band_members(band_id,user_id,role) values (%s,%s,'admin'),(%s,%s,'editor'),(%s,%s,'viewer')",(b1,U['admin'],b1,U['editor'],b1,U['viewer']))
upd="update public.bands set slug=%s where id=%s"
me('owner'); r=run(upd,('wc',b1)); ok('owner sets an ending', r==('ok',1), r)
me('admin'); r=run(upd,('wc-band',b1)); ok('admin changes the ending', r==('ok',1), r)
me('editor'); r=run(upd,('hacked',b1)); ok('editor cannot change it', r==('ok',0), r)
me('viewer'); r=run(upd,('hacked',b1)); ok('viewer cannot change it', r==('ok',0), r)
me('legacy'); r=run(upd,('hacked',b1)); ok('a non-member cannot change it', r==('ok',0), r)
cur.execute('reset role'); cur.execute("select slug from public.bands where id=%s",(b1,)); ok('only the admin change stuck', cur.fetchone()[0]=='wc-band')
me('outsider'); r=run(upd,('wc-band',b2)); ok('an ending taken by another band is refused', r[0]=='err' and 'bands_slug_key' in r[1], r)
me('outsider'); r=run(upd,('WC-Band',b2)); ok('upper case refused (so case cannot dodge uniqueness)', r[0]=='err' and 'bands_slug_check' in r[1], r)
for bad in ['a','-wc','wc_x','wc band','wc!','x'*31,'join','Invite','admin','null','']:
    me('outsider'); r=run(upd,(bad,b2)); ok(f'refused: {bad!r}', r[0]=='err', r)
for good in ['ab','a-b','wc2','2wc','x'*30,'wc-band-2']:
    me('outsider'); r=run(upd,(good,b2)); ok(f'accepted: {good!r}', r==('ok',1), r)
me('outsider'); r=run(upd,(None,b2)); ok('an ending can be cleared', r==('ok',1), r)
me('owner'); r=run("update public.bands set slug=null where id=%s",(b1,)); me('outsider'); r2=run("update public.bands set slug=null where id=%s",(b2,)); ok('several bands without an ending are fine', r[0]=='ok' and r2[0]=='ok', (r,r2))
me('viewer'); cur.execute("select slug from public.bands where id=%s",(b1,)); ok('members can read it', cur.fetchone()[0] is None)
bad=[x for x in res if not x[1]]; print(f'{len(res)-len(bad)} checks passed, {len(bad)} failed'); [print('FAIL:',x[0],x[2]) for x in bad]
