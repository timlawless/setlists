import psycopg2
U = {n: f'00000000-0000-0000-0000-00000000000{i}' for i, n in enumerate(['owner','admin','editor','viewer','outsider','legacy'], 1)}
conn = psycopg2.connect(dbname='t1', user='postgres', host='/var/run/postgresql'); conn.autocommit = True; cur = conn.cursor()
res=[]
def me(n): cur.execute('reset role'); cur.execute("select set_config('request.jwt.claim.sub',%s,false)",(U[n],)); cur.execute('set role authenticated')
def run(sql,a=None):
    try: cur.execute(sql,a); return ('ok',cur.rowcount)
    except psycopg2.Error as e: return ('err',str(e).splitlines()[0])
def ok(label,cond,d=''): res.append((label,cond,d))
me('owner'); cur.execute("select id from public.create_band('V5 Band')"); band=cur.fetchone()[0]
cur.execute("insert into public.setlists(band_id,name,created_by) values (%s,'Set 1',%s) returning id",(band,U['owner'])); s1=cur.fetchone()[0]
cur.execute("insert into public.setlists(band_id,name,created_by) values (%s,'Set 2',%s) returning id",(band,U['owner'])); s2=cur.fetchone()[0]
cur.execute('reset role')
cur.execute("insert into public.band_members(band_id,user_id,role) values (%s,%s,'editor'),(%s,%s,'viewer')",(band,U['editor'],band,U['viewer']))
upd="update public.band_members set last_setlist_id=%s where band_id=%s and user_id=%s"
me('owner');  r=run(upd,(s2,band,U['owner']));  ok('owner saves own last setlist', r==('ok',1), r)
me('viewer'); r=run(upd,(s1,band,U['viewer'])); ok('viewer saves own last setlist', r==('ok',1), r)
me('editor'); r=run(upd,(s1,band,U['viewer'])); ok("editor cannot change someone else's", r[0]=='ok' and r[1]==0, r)
me('outsider'); r=run(upd,(s1,band,U['owner'])); ok("outsider cannot change a member's", r[0]=='ok' and r[1]==0, r)
me('editor'); r=run("update public.band_members set role='owner' where band_id=%s and user_id=%s",(band,U['editor'])); ok('access level still cannot be edited directly', r[0]=='err', r)
me('owner'); cur.execute("select last_setlist_id from public.band_members where band_id=%s and user_id=%s",(band,U['owner'])); ok('saved value readable', cur.fetchone()[0]==s2)
me('owner'); run("update public.setlists set deleted_at=now() where id=%s",(s2,))  # soft delete keeps the pointer; the app falls back when the setlist is not in the list
cur.execute('reset role'); cur.execute("delete from public.setlists where id=%s",(s2,))
cur.execute("select last_setlist_id from public.band_members where band_id=%s and user_id=%s",(band,U['owner'])); ok('deleting the setlist clears the pointer', cur.fetchone()[0] is None)
bad=[x for x in res if not x[1]]
print(f'{len(res)-len(bad)} checks passed, {len(bad)} failed'); [print('FAIL:',b[0],b[2]) for b in bad]
