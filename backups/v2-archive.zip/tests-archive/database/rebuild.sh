#!/bin/sh
# usage: rebuild.sh <v4 sql file>
su postgres -c "psql -q -c 'drop database if exists t1' -c 'create database t1'" >/dev/null 2>&1
for f in /tmp/stub.sql /mnt/user-data/outputs/setlist_schema_v1.sql /mnt/user-data/outputs/v6-update/schema_v2_change_reason.sql /mnt/user-data/outputs/v7-update/schema_v3_roles.sql; do su postgres -c "psql -q -v ON_ERROR_STOP=1 -d t1 -f $f" >/dev/null 2>&1 || echo "load problem: $f"; done
su postgres -c "psql -q -d t1" >/dev/null 2>&1 <<'SQL'
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-000000000001','owner@x'),('00000000-0000-0000-0000-000000000002','admin@x'),
 ('00000000-0000-0000-0000-000000000003','editor@x'),('00000000-0000-0000-0000-000000000004','viewer@x'),
 ('00000000-0000-0000-0000-000000000005','outsider@x'),('00000000-0000-0000-0000-000000000006','legacy@x');
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',false);
set role authenticated;
select (public.create_band('Legacy Band')).id as legacy_band \gset
reset role;
insert into public.band_members(band_id,user_id,role) values (:'legacy_band','00000000-0000-0000-0000-000000000006','member');
SQL
chmod 644 "$1"; su postgres -c "psql -q -v ON_ERROR_STOP=1 -d t1 -f $1" >/dev/null 2>&1 && echo "v4 applied"
su postgres -c "python3 ${TESTFILE:-/tmp/perm_test.py}"
