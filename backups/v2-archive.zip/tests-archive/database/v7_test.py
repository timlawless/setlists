import psycopg2
U = {n: f'00000000-0000-0000-0000-00000000000{i}' for i, n in enumerate(['owner','admin','editor','viewer','outsider','legacy'], 1)}
conn = psycopg2.connect(dbname='t1', user='postgres', host='/var/run/postgresql'); conn.autocommit = True; cur = conn.cursor()
res=[]
def me(n): cur.execute('reset role'); cur.execute("select set_config('request.jwt.claim.sub',%s,false)",(U[n],)); cur.execute('set role authenticated')
def run(sql,a=None):
    try: cur.execute(sql,a); return ('ok',cur.rowcount)
    except psycopg2.Error as e: return ('err',type(e).__name__)
def ok(l,c,d=''): res.append((l,c,d))
PNG='data:image/png;base64,iVBORw0KGgo='
me('owner'); cur.execute("select id from public.create_band('Logo Band')"); b=cur.fetchone()[0]
cur.execute('reset role'); cur.execute("insert into public.band_members(band_id,user_id,role) values (%s,%s,'admin'),(%s,%s,'editor'),(%s,%s,'viewer')",(b,U['admin'],b,U['editor'],b,U['viewer']))
upd="update public.bands set logo=%s where id=%s"
me('owner'); r=run(upd,(PNG,b)); ok('owner sets the logo', r==('ok',1), r)
me('admin'); r=run(upd,(PNG+'AAAA',b)); ok('admin sets the logo', r==('ok',1), r)
me('editor'); r=run(upd,('data:image/png;base64,EVIL',b)); ok('editor cannot change the logo', r==('ok',0), r)
me('viewer'); r=run(upd,(PNG,b)); ok('viewer cannot change the logo', r==('ok',0), r)
me('outsider'); r=run(upd,(PNG,b)); ok('outsider cannot change the logo', r==('ok',0), r)
me('admin'); r=run(upd,('javascript:alert(1)',b)); ok('non-image text is rejected', r[0]=='err', r)
me('admin'); r=run(upd,('data:image/svg+xml;base64,PHN2Zz4=',b)); ok('svg data urls are rejected', r[0]=='err', r)
me('admin'); r=run(upd,('data:image/png;base64,'+'A'*260000,b)); ok('oversized logo is rejected', r[0]=='err', r)
me('admin'); r=run(upd,(None,b)); ok('admin removes the logo', r==('ok',1), r)
me('owner'); run(upd,(PNG,b)); me('viewer'); cur.execute("select logo from public.bands where id=%s",(b,)); ok('a member can read the logo', cur.fetchone()[0]==PNG)
me('outsider'); cur.execute("select count(*) from public.bands where id=%s",(b,)); ok('an outsider cannot see the band or logo', cur.fetchone()[0]==0)
bad=[x for x in res if not x[1]]; print(f'{len(res)-len(bad)} checks passed, {len(bad)} failed'); [print('FAIL:',x[0],x[2]) for x in bad]
