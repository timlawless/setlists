import psycopg2
U = {n: f'00000000-0000-0000-0000-00000000000{i}' for i, n in enumerate(['owner','admin','editor','viewer','outsider','legacy'], 1)}
conn = psycopg2.connect(dbname='t1', user='postgres', host='/var/run/postgresql'); conn.autocommit = True; cur = conn.cursor()
res=[]
def me(n): cur.execute('reset role'); cur.execute("select set_config('request.jwt.claim.sub',%s,false)",(U[n],)); cur.execute('set role authenticated')
def ok(l,c,d=''): res.append((l,c,d))
def count_log(b): cur.execute('reset role'); cur.execute("select count(*) from public.change_log where band_id=%s",(b,)); return cur.fetchone()[0]
me('owner'); cur.execute("select id from public.create_band('Doomed')"); b1=cur.fetchone()[0]
cur.execute("select id from public.create_band('Survivor')"); b2=cur.fetchone()[0]
for b in (b1,b2):
    cur.execute("insert into public.songs(band_id,title,created_by) values (%s,'S',%s) returning id",(b,U['owner'])); sid=cur.fetchone()[0]
    cur.execute("insert into public.setlists(band_id,name,created_by) values (%s,'L',%s)",(b,U['owner']))
cur.execute('reset role'); cur.execute("insert into public.band_members(band_id,user_id,role) values (%s,%s,'editor')",(b1,U['editor']))
ok('history exists for both bands', count_log(b1)>0 and count_log(b2)>0)
n2=count_log(b2)
me('editor'); cur.execute("delete from public.bands where id=%s returning id",(b1,)); ok('editor cannot delete the band', cur.rowcount==0)
ok('history untouched by a refused delete', count_log(b1)>0)
me('owner'); cur.execute("delete from public.bands where id=%s returning id",(b1,)); ok('owner deletes the band', cur.rowcount==1)
ok("the deleted band's history is purged", count_log(b1)==0)
ok("the other band's history is untouched", count_log(b2)==n2)
cur.execute('reset role'); cur.execute("select (select count(*) from public.songs where band_id=%s),(select count(*) from public.setlists where band_id=%s),(select count(*) from public.band_members where band_id=%s)",(b1,b1,b1))
ok('songs, setlists and members removed with the band', cur.fetchone()==(0,0,0))
# the delete-with-select the app uses returns the deleted row for the owner and nothing for others
me('owner'); cur.execute("delete from public.bands where id=%s returning id",(b2,)); ok('owner delete returns the row (what the app checks)', cur.rowcount==1)
bad=[r for r in res if not r[1]]; print(f'{len(res)-len(bad)} checks passed, {len(bad)} failed'); [print('FAIL:',b[0],b[2]) for b in bad]
