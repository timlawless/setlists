import psycopg2, psycopg2.errors as E
U = {n: f'00000000-0000-0000-0000-00000000000{i}' for i, n in enumerate(['owner','admin','editor','viewer','outsider','legacy'], 1)}
conn = psycopg2.connect(dbname='t1', user='postgres', host='/var/run/postgresql'); conn.autocommit = True
cur = conn.cursor()
fails = []; passed = 0
def me(name):
    cur.execute('reset role'); cur.execute("select set_config('request.jwt.claim.sub', %s, false)", (U[name],)); cur.execute('set role authenticated')
def admin(): cur.execute('reset role')
def run(sql, args=None):
    try:
        cur.execute(sql, args); rc = cur.rowcount
        try: return ('ok', cur.fetchall(), rc)
        except psycopg2.ProgrammingError: return ('ok', None, rc)
    except psycopg2.Error as e:
        return ('err', type(e).__name__ + ': ' + str(e).splitlines()[0], 0)
def check(label, cond, detail=''):
    global passed
    if cond: passed += 1
    else: fails.append(f'{label} {detail}')
def allowed(label, r): check(label + ' (should be allowed)', r[0] == 'ok' and r[2] != 0, str(r))
def blocked(label, r): check(label + ' (should be blocked)', r[0] == 'err' or r[2] == 0, str(r))

# --- band and members set up the way the app does it
me('owner'); r = run("select id from public.create_band('Test Band')"); band = r[1][0][0] if r[0]=='ok' else None
check('owner creates band', band is not None, str(r))
admin(); cur.execute("select id from public.bands where name='Legacy Band'"); legacy = cur.fetchone()[0]
me('owner')
cur.execute("insert into public.band_invites(band_id,created_by,role) values (%s,%s,'editor') returning code",(band,U['owner'])); ed_code = cur.fetchone()[0]
cur.execute("insert into public.band_invites(band_id,created_by,role) values (%s,%s,'viewer') returning code",(band,U['owner'])); vw_code = cur.fetchone()[0]
for n, code in [('admin', ed_code), ('editor', ed_code), ('viewer', vw_code)]:
    me(n); r = run("select public.join_band(%s)", (code,)); check(f'{n} joins', r[0]=='ok', str(r))
me('owner'); allowed('owner promotes joiner to admin', run("select public.set_member_role(%s,%s,'admin')", (band, U['admin'])))
admin(); cur.execute("select user_id, role from public.band_members where band_id=%s", (band,)); roles = {u: r for u, r in cur.fetchall()}
check('levels after joining', roles == {U['owner']:'owner', U['admin']:'admin', U['editor']:'editor', U['viewer']:'viewer'}, str(roles))

# --- songs: who can write
song = {}
for n in ['owner','admin','editor']:
    me(n); r = run("insert into public.songs(band_id,title,created_by) values (%s,%s,%s) returning id", (band, f'Song by {n}', U[n])); allowed(f'{n} adds a song', r)
    if r[0]=='ok': song[n] = r[1][0][0]
me('viewer'); blocked('viewer adds a song', run("insert into public.songs(band_id,title) values (%s,'nope')", (band,)))
me('outsider'); blocked('outsider adds a song', run("insert into public.songs(band_id,title) values (%s,'nope')", (band,)))
me('editor'); allowed('editor edits a song', run("update public.songs set bpm=100, change_note='faster' where id=%s", (song['owner'],)))
me('viewer'); blocked('viewer edits a song', run("update public.songs set bpm=130 where id=%s", (song['owner'],)))
admin(); cur.execute("select bpm from public.songs where id=%s", (song['owner'],)); check('viewer edit did not change data', cur.fetchone()[0]==100)
me('viewer'); r = run("select count(*) from public.songs where band_id=%s", (band,)); check('viewer can read all songs', r[0]=='ok' and r[1][0][0]==3, str(r))
me('outsider'); r = run("select count(*) from public.songs where band_id=%s", (band,)); check('outsider sees no songs', r[0]=='ok' and r[1][0][0]==0, str(r))
me('editor'); allowed('editor soft-deletes a song', run("update public.songs set deleted_at=now() where id=%s", (song['editor'],)))
me('editor'); blocked('editor hard-deletes a song', run("delete from public.songs where id=%s", (song['editor'],)))
me('admin'); allowed('admin hard-deletes a song', run("delete from public.songs where id=%s", (song['editor'],)))

# --- setlists, setlist songs, links
me('editor'); r = run("insert into public.setlists(band_id,name,created_by) values (%s,'Gig 1',%s) returning id",(band,U['editor'])); allowed('editor creates setlist', r); sl = r[1][0][0]
me('editor'); allowed('editor adds song to setlist', run("insert into public.setlist_songs(band_id,setlist_id,song_id,position) values (%s,%s,%s,1)",(band,sl,song['owner'])))
me('editor'); allowed('editor adds a link', run("insert into public.song_links(band_id,song_id,url,added_by) values (%s,%s,'https://example.com',%s)",(band,song['owner'],U['editor'])))
me('viewer'); blocked('viewer creates setlist', run("insert into public.setlists(band_id,name) values (%s,'x')",(band,)))
me('viewer'); blocked('viewer adds song to setlist', run("insert into public.setlist_songs(band_id,setlist_id,song_id,position) values (%s,%s,%s,2)",(band,sl,song['admin'])))
me('viewer'); blocked('viewer adds a link', run("insert into public.song_links(band_id,song_id,url) values (%s,%s,'https://x.com')",(band,song['owner'])))
me('viewer'); blocked('viewer edits a setlist', run("update public.setlists set name='hacked' where id=%s",(sl,)))
me('viewer'); r = run("select count(*) from public.setlist_songs where setlist_id=%s",(sl,)); check('viewer reads setlist songs', r[0]=='ok' and r[1][0][0]==1, str(r))

# --- history
me('viewer'); r = run("select count(*) from public.change_log where band_id=%s",(band,)); check('viewer reads history', r[0]=='ok' and r[1][0][0]>0, str(r))
me('viewer'); blocked('viewer writes history', run("insert into public.change_log(band_id,table_name,row_id,op) values (%s,'songs',%s,'INSERT')",(band,song['owner'])))
admin(); cur.execute("select reason from public.change_log where row_id=%s and op='UPDATE'",(song['owner'],)); check('reason recorded in history', ('faster',) in cur.fetchall())

# --- band settings
me('editor'); blocked('editor changes band colour', run("update public.bands set theme='{\"accent\":\"#ff0000\"}' where id=%s",(band,)))
me('viewer'); blocked('viewer renames band', run("update public.bands set name='x' where id=%s",(band,)))
me('admin'); allowed('admin changes band colour', run("update public.bands set theme='{\"accent\":\"#112233\"}' where id=%s",(band,)))
me('owner'); allowed('owner renames band', run("update public.bands set name='Test Band 2' where id=%s",(band,)))
me('admin'); blocked('admin changes band creator column', run("update public.bands set created_by=%s where id=%s",(U['admin'],band)))
me('admin'); blocked('admin deletes band', run("delete from public.bands where id=%s",(band,)))
me('editor'); blocked('editor deletes band', run("delete from public.bands where id=%s",(band,)))

# --- member table protections
me('editor'); blocked('editor edits own access level directly', run("update public.band_members set role='owner' where band_id=%s and user_id=%s",(band,U['editor'])))
me('editor'); allowed('editor sets own instrument roles', run("update public.band_members set roles=array['bassist','singer'] where band_id=%s and user_id=%s",(band,U['editor'])))
me('viewer'); allowed('viewer sets own instrument roles', run("update public.band_members set roles=array['drummer'] where band_id=%s and user_id=%s",(band,U['viewer'])))
me('editor'); blocked('invalid instrument role rejected', run("update public.band_members set roles=array['dancer'] where band_id=%s and user_id=%s",(band,U['editor'])))
me('editor'); blocked("editor edits someone else's instrument roles", run("update public.band_members set roles=array['singer'] where band_id=%s and user_id=%s",(band,U['viewer'])))
me('editor'); blocked('editor inserts a member directly', run("insert into public.band_members(band_id,user_id,role) values (%s,%s,'owner')",(band,U['outsider'])))
me('admin'); blocked('admin deletes a member directly', run("delete from public.band_members where band_id=%s and user_id=%s",(band,U['editor'])))
admin(); blocked('a second owner is impossible', run("update public.band_members set role='owner' where band_id=%s and user_id=%s",(band,U['editor'])))
me('viewer'); r = run("select count(*) from public.band_members where band_id=%s",(band,)); check('viewer sees the member list', r[0]=='ok' and r[1][0][0]==4, str(r))
me('viewer'); r = run("select count(*) from public.profiles"); check('viewer sees names of bandmates only (no outsider)', r[0]=='ok' and r[1][0][0] >= 4, str(r))
me('outsider'); r = run("select count(*) from public.band_members where band_id=%s",(band,)); check('outsider sees no members', r[0]=='ok' and r[1][0][0]==0, str(r))

# --- set_member_role
me('editor'); blocked('editor changes access level', run("select public.set_member_role(%s,%s,'admin')",(band,U['editor'])))
me('viewer'); blocked('viewer changes access level', run("select public.set_member_role(%s,%s,'editor')",(band,U['viewer'])))
me('outsider'); blocked('outsider changes access level', run("select public.set_member_role(%s,%s,'viewer')",(band,U['viewer'])))
me('admin'); allowed('admin upgrades viewer to editor', run("select public.set_member_role(%s,%s,'editor')",(band,U['viewer'])))
me('viewer'); allowed('upgraded viewer can now edit', run("insert into public.songs(band_id,title,created_by) values (%s,'Now allowed',%s)",(band,U['viewer'])))
me('admin'); allowed('admin downgrades editor to viewer', run("select public.set_member_role(%s,%s,'viewer')",(band,U['viewer'])))
me('viewer'); blocked('downgraded viewer can no longer edit', run("insert into public.songs(band_id,title) values (%s,'blocked again')",(band,)))
me('admin'); blocked('admin changes the owner', run("select public.set_member_role(%s,%s,'viewer')",(band,U['owner'])))
me('admin'); blocked('admin makes someone owner', run("select public.set_member_role(%s,%s,'owner')",(band,U['editor'])))
me('owner'); blocked('invalid access level', run("select public.set_member_role(%s,%s,'superuser')",(band,U['editor'])))
me('owner'); blocked('owner changes own level', run("select public.set_member_role(%s,%s,'viewer')",(band,U['owner'])))

# --- invites
me('editor'); blocked('editor creates invite', run("insert into public.band_invites(band_id,created_by,role) values (%s,%s,'editor')",(band,U['editor'])))
me('viewer'); r = run("select count(*) from public.band_invites where band_id=%s",(band,)); check('viewer cannot list invite codes', r[0]=='ok' and r[1][0][0]==0, str(r))
me('admin'); allowed('admin creates invite', run("insert into public.band_invites(band_id,created_by,role) values (%s,%s,'viewer')",(band,U['admin'])))
me('admin'); blocked('invite for admin level rejected', run("insert into public.band_invites(band_id,created_by,role) values (%s,%s,'admin')",(band,U['admin'])))
me('editor'); run("select public.join_band(%s)",(vw_code,)); admin(); cur.execute("select role from public.band_members where band_id=%s and user_id=%s",(band,U['editor'])); check('existing editor keeps level when using a viewer code', cur.fetchone()[0]=='editor')
admin(); cur.execute("update public.band_invites set expires_at = now() - interval '1 day' where code=%s",(ed_code,))
me('outsider'); blocked('expired code rejected', run("select public.join_band(%s)",(ed_code,)))

# --- remove_member / leave
me('editor'); blocked('editor removes another person', run("select public.remove_member(%s,%s)",(band,U['viewer'])))
me('admin'); blocked('admin removes the owner', run("select public.remove_member(%s,%s)",(band,U['owner'])))
me('owner'); blocked('owner cannot leave', run("select public.remove_member(%s,%s)",(band,U['owner'])))
me('viewer'); allowed('viewer leaves the band', run("select public.remove_member(%s,%s)",(band,U['viewer'])))
me('viewer'); r = run("select count(*) from public.songs where band_id=%s",(band,)); check('person who left sees nothing', r[0]=='ok' and r[1][0][0]==0, str(r))
me('admin'); allowed('admin removes an editor', run("select public.remove_member(%s,%s)",(band,U['editor'])))
me('outsider'); blocked('outsider removes someone', run("select public.remove_member(%s,%s)",(band,U['admin'])))


# --- transfer of ownership
admin(); cur.execute("insert into public.band_members(band_id,user_id,role) values (%s,%s,'editor')",(band,U['editor']))
def refused_for_owner_only(label, r):
    check(label + ' (refused because only the owner may)', r[0]=='err' and 'Only the owner can transfer ownership' in r[1], str(r))
me('admin'); refused_for_owner_only('admin hands ownership to an editor', run("select public.transfer_ownership(%s,%s)",(band,U['editor'])))
me('admin'); refused_for_owner_only('admin hands ownership to the owner', run("select public.transfer_ownership(%s,%s)",(band,U['owner'])))
me('editor'); refused_for_owner_only('editor takes ownership', run("select public.transfer_ownership(%s,%s)",(band,U['editor'])))
me('outsider'); refused_for_owner_only('outsider tries to transfer', run("select public.transfer_ownership(%s,%s)",(band,U['owner'])))
admin(); cur.execute("select user_id, role from public.band_members where band_id=%s",(band,)); r0 = dict(cur.fetchall())
check('nothing changed after refused transfers', r0.get(U['owner'])=='owner' and r0.get(U['admin'])=='admin' and r0.get(U['editor'])=='editor', str(r0))
me('owner'); blocked('owner transfers to self', run("select public.transfer_ownership(%s,%s)",(band,U['owner'])))
me('owner'); blocked('owner transfers to a non-member', run("select public.transfer_ownership(%s,%s)",(band,U['outsider'])))
me('owner'); allowed('owner transfers ownership to an editor and gets it back', run("select public.transfer_ownership(%s,%s)",(band,U['editor'])))
me('editor'); allowed('editor-turned-owner hands it back', run("select public.transfer_ownership(%s,%s)",(band,U['owner'])))
admin(); cur.execute("update public.band_members set role='editor' where band_id=%s and user_id=%s",(band,U['editor']))
me('owner'); allowed('owner transfers ownership to admin', run("select public.transfer_ownership(%s,%s)",(band,U['admin'])))
admin(); cur.execute("select user_id, role from public.band_members where band_id=%s",(band,)); roles2 = dict(cur.fetchall())
check('roles swapped after transfer', roles2.get(U['admin'])=='owner' and roles2.get(U['owner'])=='admin', str(roles2))
cur.execute("select count(*) from public.band_members where band_id=%s and role='owner'",(band,)); check('exactly one owner after transfer', cur.fetchone()[0]==1)
me('owner'); blocked('old owner (now admin) deletes band', run("delete from public.bands where id=%s",(band,)))
me('owner'); blocked('old owner removes the new owner', run("select public.remove_member(%s,%s)",(band,U['admin'])))
me('owner'); blocked('old owner demotes the new owner', run("select public.set_member_role(%s,%s,'viewer')",(band,U['admin'])))
me('owner'); blocked('old owner transfers again', run("select public.transfer_ownership(%s,%s)",(band,U['owner'])))
me('owner'); allowed('old owner still edits as admin', run("insert into public.songs(band_id,title,created_by) values (%s,'Admin song',%s)",(band,U['owner'])))
me('owner'); allowed('old owner can still make invites', run("insert into public.band_invites(band_id,created_by,role) values (%s,%s,'viewer')",(band,U['owner'])))
me('admin'); allowed('new owner renames band', run("update public.bands set name='Test Band 3' where id=%s",(band,)))
me('admin'); allowed('new owner transfers back', run("select public.transfer_ownership(%s,%s)",(band,U['owner'])))
admin(); cur.execute("select user_id, role from public.band_members where band_id=%s",(band,)); roles3 = dict(cur.fetchall())
check('roles restored', roles3.get(U['owner'])=='owner' and roles3.get(U['admin'])=='admin', str(roles3))
admin(); cur.execute("delete from public.band_members where band_id=%s and user_id=%s",(band,U['editor']))

# --- legacy band: the old "member" is now an editor and can still work
me('legacy'); allowed('migrated legacy member can edit', run("insert into public.songs(band_id,title,created_by) values (%s,'Legacy song',%s)",(legacy,U['legacy'])))
me('legacy'); blocked('migrated legacy member cannot change band colour', run("update public.bands set theme='{}' where id=%s",(legacy,)))

# --- owner may delete their band (cascades)
me('owner'); allowed('owner deletes band', run("delete from public.bands where id=%s",(band,)))
admin(); cur.execute("select count(*) from public.songs where band_id=%s",(band,)); check('band delete cascades', cur.fetchone()[0]==0)

print(f'{passed} checks passed, {len(fails)} failed')
for f in fails: print('FAIL:', f)
