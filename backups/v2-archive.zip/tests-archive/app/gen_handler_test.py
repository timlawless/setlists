import re
src=open('/tmp/v14.mjs',encoding='utf-8').read()
def between(a,b):
    i=src.index(a); j=src.index(b,i); return src[i:j]
cached=between("async function cached","// ---- offline editing")
offline=between("// ---- offline editing","// ---- appearance")
listh=re.search(r"\$\('list'\)\.onclick = async \(e\) => \{.*?\n\};\n",src,re.S).group(0)
library=between("// ---- song library","// ---- gig mode")
pre=r"""
const els={}; const mk=()=>({hidden:false,textContent:'',innerHTML:'',value:'',dataset:{},contains:()=>false,addEventListener(){},showModal(){this.opened=true},close(){this.closed=true},classList:{add(){},remove(){}}});
const $=(id)=>(els[id] ||= mk());
const window={addEventListener(){}}; const document={addEventListener(){},activeElement:null}; const setInterval=()=>0; const navigator={onLine:false};
const store={}; const localStorage={getItem:(k)=>(k in store?store[k]:null),setItem:(k,v)=>{store[k]=String(v)},removeItem:(k)=>{delete store[k]}};
let user={id:'U1'}, items=[], setlistId='L1', bandId='B1', openId=null, matches=[]; const ck=(k)=>`c:${user.id}:${k}`;
const esc=(s)=>String(s??'').replace(/[&<>"']/g,(c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const toasts=[]; const say=(m)=>toasts.push(m); let renders=0; const render=()=>{renders++}; const loadSetlist=async()=>{}; const loadLinks=()=>{}; const canEdit=()=>true;
const norm=(u)=>{u=(u||'').trim();return !u?null:/^https?:\/\//i.test(u)?u:'https://'+u}; const toggleClick=async()=>{}; globalThis.confirm=()=>true;
// the network is down: every call fails like a lost connection
const lost={data:null,error:{message:'TypeError: Failed to fetch',code:''}};
const b=()=>{const q={};for(const m of ['select','insert','update','eq','is','order','limit','maybeSingle','single'])q[m]=()=>q;q.then=(r)=>r(lost);return q};
const sb={from:b}; const must=async(p)=>{const r=await p;if(r.error)throw r.error;return r.data};
function fail(m){console.log('FAIL:',m);process.exit(1)} const ok=(c,m)=>{if(!c)fail(m)};
"""
body=r"""
const song=(id,t,bpm)=>({id,band_id:'B1',title:t,artist:'',version_label:'',bpm,musical_key:'E',time_signature:'4/4',chords:'',root_notes:'',notes:'',lyrics_url:null,youtube_url:null});
items=[{id:'R1',position:1,songs:song('S1','One',100)},{id:'R2',position:2,songs:song('S2','Two',90)}];
const fields=(over)=>Object.entries({title:'One',artist:'',version_label:'',time_signature:'4/4',bpm:'100',musical_key:'E',chords:'',root_notes:'',notes:'',lyrics_url:'',youtube_url:'',...over}).map(([f,v])=>({dataset:{f},value:v}));
const art=(id,sid,extra={})=>({dataset:{id,sid},querySelectorAll:()=>extra.fields||[],querySelector:(sel)=>(extra.q&&extra.q[sel])||{value:''}});
const click=async(a,article,extra={})=>{const btn={dataset:{a,...extra},closest:()=>article};await els.list.onclick({target:{closest:()=>btn}})};
const wait=()=>new Promise((r)=>setTimeout(r,20));
loadQ(); queue=[]; issues=[];
// save
await click('save',art('R1','S1',{fields:fields({bpm:'110',notes:'n'}),q:{'[data-r="reason"]':{value:'why'}}})); await wait();
ok(queue.length===1&&queue[0].t==='song','one edit queued'); const op=queue[0];
ok(JSON.stringify(op.set)==='{"bpm":110,"notes":"n"}'&&JSON.stringify(op.base)==='{"bpm":100,"notes":""}'&&op.note==='why'&&op.sid==='S1','only changed fields, with the values they had: '+JSON.stringify(op));
ok(items[0].songs.bpm===110&&JSON.parse(store['c:U1:items:L1'])[0].songs.bpm===110,'screen and saved copy updated straight away');
ok(toasts.at(-1).includes('saved on this device')||toasts.at(-1).includes('Saved on this device'),'offline message: '+toasts.at(-1));
queue=[]; await click('save',art('R1','S1',{fields:fields({bpm:'110',notes:'n'})})); ok(queue.length===0&&toasts.at(-1)==='Nothing has changed','no change, nothing queued');
await click('save',art('R1','S1',{fields:fields({title:''})})); ok(queue.length===0&&toasts.at(-1)==='A title is needed','title still required');
// reorder
queue=[]; await click('down',art('R1','S1')); await wait();
ok(items[0].id==='R2'&&items[1].id==='R1','order changed on screen'); ok(queue.length===2&&queue.every((o)=>o.t==='slPos')&&queue.find((o)=>o.id==='R1').position===2&&queue.find((o)=>o.id==='R2').position===1,'two position changes queued');
ok(JSON.parse(store['c:U1:items:L1'])[0].id==='R2','saved copy reordered');
await click('up',art('R2','S2')); ok(items[0].id==='R2','first row cannot move up'); // R2 is first now
// remove from setlist
queue=[]; await click('remove',art('R2','S2')); ok(items.length===1&&items[0].id==='R1'&&queue[0].t==='slRemove'&&queue[0].id==='R2','removed from setlist');
// delete the song
items=[{id:'R1',position:1,songs:song('S1','One',100)},{id:'R2',position:2,songs:song('S2','Two',90)}]; queue=[];
await click('delsong',art('R2','S2')); ok(items.length===1&&queue[0].t==='songDel'&&queue[0].sid==='S2','song deleted everywhere on screen');
// links: with and without a saved copy
queue=[]; store['c:U1:links:S1']=JSON.stringify([{id:'old',kind:'tab',label:'Old',url:'https://e.com/o'}]);
await click('addlink',art('R1','S1',{q:{'[data-l="kind"]':{value:'tab'},'[data-l="label"]':{value:'New'},'[data-l="url"]':{value:'e.com/n'}}})); await wait();
const lk=JSON.parse(store['c:U1:links:S1']); ok(lk.length===2&&lk[1].url==='https://e.com/n'&&queue[0].t==='linkAdd'&&queue[0].row.id===lk[1].id&&queue[0].row.url==='https://e.com/n','link shown and queued');
await click('dellink',art('R1','S1'),{lid:'old'}); ok(JSON.parse(store['c:U1:links:S1']).every((x)=>x.id!=='old')&&queue.at(-1).t==='linkDel'&&queue.at(-1).id==='old','link removed and queued');
queue=[]; delete store['c:U1:links:S3']; items.push({id:'R9',position:5,songs:song('S3','Three',80)});
await click('addlink',art('R9','S3',{q:{'[data-l="kind"]':{value:'tab'},'[data-l="label"]':{value:''},'[data-l="url"]':{value:'x.com'}}})); ok(store['c:U1:links:S3']===undefined&&queue.length===1,'no saved list means no half list is stored');
await click('addlink',art('R9','S3',{q:{'[data-l="url"]':{value:''},'[data-l="kind"]':{value:'tab'},'[data-l="label"]':{value:''}}})); ok(toasts.at(-1)==='Add a link first','empty link refused');

// library: open from the saved copy while offline
items=[{id:'R1',position:1,songs:song('S1','One',100)}]; queue=[];
store['c:U1:lib:B1']=JSON.stringify([song('S1','One',100),song('S2','Two',90),song('S3','Three',80)]);
await els.addBtn.onclick(); ok(lib.length===3&&libFor==='B1'&&els.addDlg.opened===true,'library opens offline from the saved copy');
ok(els.libList.innerHTML.includes('In setlist')&&(els.libList.innerHTML.match(/data-add=/g)||[]).length===2,'in-setlist label and add buttons');
els.libList.onclick({target:{dataset:{add:'S3'}}}); ok(items.length===2&&items[1].songs.id==='S3'&&items[1].position===2&&queue[0].t==='slAdd'&&queue[0].row.song_id==='S3'&&queue[0].row.position===2,'song added to the setlist locally and queued');
ok(!els.addDlg.closed,'dialog stays open when adding from the list'); ok(JSON.parse(store['c:U1:items:L1']).length===2,'saved copy updated');
// create a new song offline
queue=[]; els.nTitle=mk(); els.nTitle.value='Brand New'; els.nArtist=mk(); els.nArtist.value='Me'; els.nBpm=mk(); els.nBpm.value='88'; els.nKey=mk(); els.nKey.value='A';
els.addNew.onclick(); ok(queue.length===2&&queue[0].t==='songNew'&&queue[1].t==='slAdd'&&queue[1].row.song_id===queue[0].row.id,'new song then its setlist entry, in that order');
ok(queue[0].row.title==='Brand New'&&queue[0].row.bpm===88&&queue[0].row.musical_key==='A'&&queue[0].row.created_by==='U1','new song fields'); ok(items.at(-1).songs.title==='Brand New'&&lib.some((x)=>x.title==='Brand New'),'shown at once'); ok(els.nTitle.value==='','form cleared'); ok(els.addDlg.closed===true,'dialog closes after create');
els.nTitle.value=''; queue=[]; els.addNew.onclick(); ok(queue.length===0&&toasts.at(-1)==='A title is needed','title required');
// delete from the library
queue=[]; els.libList.onclick({target:{dataset:{del:'S2'}}}); ok(!lib.some((x)=>x.id==='S2')&&queue[0].t==='songDel'&&queue[0].sid==='S2','library delete queued'); ok(JSON.parse(store['c:U1:lib:B1']).every((x)=>x.id!=='S2'),'saved library updated');
// while changes wait, the saved copy is shown instead of the server
queue=[{t:'songDel'}]; store['c:U1:probe']=JSON.stringify({from:'device'}); const got=await cached(ck('probe'),async()=>({from:'server'})); ok(got.from==='device','local copy shown while changes wait');
queue=[]; const got2=await cached(ck('probe'),async()=>({from:'server'})); ok(got2.from==='server','server shown when nothing is waiting');
const gone=await cached(ck('missing'),async()=>({from:'server'})); ok(gone.from==='server','no saved copy: fall back to the server');
console.log('offline screen actions checks passed');
"""
open('/tmp/handler_test.mjs','w').write(pre+cached+offline+listh+library+body)
