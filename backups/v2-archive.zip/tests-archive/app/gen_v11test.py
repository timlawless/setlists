import re,subprocess
src=open('/tmp/v11.mjs',encoding='utf-8').read()
def between(a,b):
    i=src.index(a); j=src.index(b,i); return src[i:j]
libblock=between("let lib = [];","// ---- gig mode")
mk=re.search(r"async function showSetlist.*?async function makeSetlist\(inp\) \{.*?\n\}\n",src,re.S).group(0)
menu=between("$('slRenameBtn').onclick","// ---- the setlist screen")
delb=between("$('delBand').onclick","$('leaveBand').onclick")
pre = r"""
const esc=(s)=>String(s??'').replace(/[&<>"']/g,(c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const els={}; const $=(id)=>(els[id] ||= {innerHTML:'',value:'',textContent:'',hidden:false,selectedOptions:[{text:'Saturday'}],dataset:{},close(){this.closed=true},showModal(){this.opened=true}});
const toasts=[]; const say=(m)=>toasts.push(m);
let ops=[]; let respond=()=>[];
const builder=(table)=>{ const b={table,steps:[]}; for(const m of ['select','insert','update','delete','eq','is','order','limit','single']) b[m]=(...a)=>{b.steps.push([m,...a]);return b}; b.then=(res,rej)=>{ops.push(b); res({data:respond(b),error:null})}; return b;};
const sb={from:builder};
const must=async(p)=>{const r=await p; if(r.error) throw r.error; return r.data;};
let items=[], bandId='B1', setlistId='L1', openId=null, user={id:'ME'}, forcePick=null;
let bandRows=[{bands:{id:'B1',name:'Weaponized Conch'},role:'owner'}];
let bandLoads=0, loads=0, closedGig=0;
const canEdit=()=>true; const loadSetlist=async()=>{loads++}, loadBand=async()=>{bandLoads++}, closeGig=()=>{closedGig++};
let askConfirm=true, askPrompt='', prompts=[];
globalThis.confirm=()=>askConfirm; globalThis.prompt=(m)=>{prompts.push(m);return askPrompt};
const store={};
const localStorage={getItem:(k)=>(k in store?store[k]:null),setItem:(k,v)=>{store[k]=String(v)},removeItem:(k)=>{delete store[k]}};
const realKeys=Object.keys; Object.keys=(o)=>(o===localStorage?realKeys(store):realKeys(o));
let bandsReloaded=0; const loadBands=async()=>{bandsReloaded++};
function fail(m){console.log('FAIL:',m);process.exit(1)}
const has=(b,m,t)=>b.steps.some((s)=>s[0]===m&&(t===undefined||JSON.stringify(s).includes(t)));
"""
body = r"""
// ---------- song library
lib=[{id:'S1',title:'Mustang Sally',artist:'Wilson Pickett',bpm:112,musical_key:'E'},{id:'S2',title:'Hard to Handle',artist:'Black Crowes',bpm:96,musical_key:'A'},{id:'S3',title:'Tom <b>',artist:'',bpm:null,musical_key:null}];
items=[{id:'R1',position:1,songs:{id:'S1'}}];
$('songSearch').value=''; drawLib(); let h=els.libList.innerHTML;
if(!h.includes('In setlist')||(h.match(/data-add=/g)||[]).length!==2||(h.match(/data-del=/g)||[]).length!==3) fail('library rows/buttons');
if(!h.includes('Tom &lt;b&gt;')) fail('library escaping');
$('songSearch').value='black'; drawLib(); h=els.libList.innerHTML; if(!h.includes('Hard to Handle')||h.includes('Mustang')) fail('search by artist');
$('songSearch').value='mustang'; drawLib(); h=els.libList.innerHTML; if(!h.includes('Mustang')||h.includes('Hard to')) fail('search by title');
$('songSearch').value='zzz'; drawLib(); if(!els.libList.innerHTML.includes('No songs found')) fail('empty search');
$('songSearch').value=''; drawLib();
respond=(b)=>b.steps.some((s)=>s[0]==='select'&&JSON.stringify(s).includes('position'))?[{position:4}]:[];
ops=[]; loads=0; await els.libList.onclick({target:{dataset:{add:'S2'}}});
const ins=ops.find((b)=>b.table==='setlist_songs'&&has(b,'insert')); const row=ins.steps.find((s)=>s[0]==='insert')[1];
if(row.song_id!=='S2'||row.position!==5||row.setlist_id!=='L1'||row.band_id!=='B1') fail('add row '+JSON.stringify(row));
if(els.addDlg&&els.addDlg.closed) fail('dialog should stay open when adding from the list'); if(loads!==1) fail('setlist reload after add');
askConfirm=false; ops=[]; await els.libList.onclick({target:{dataset:{del:'S3'}}}); if(ops.length) fail('deleted without confirming');
askConfirm=true; ops=[]; loads=0; openId='S3'; await els.libList.onclick({target:{dataset:{del:'S3'}}});
const up=ops.find((b)=>b.table==='songs'&&has(b,'update')); if(!up||!JSON.stringify(up.steps).includes('deleted_at')||!JSON.stringify(up.steps).includes('"S3"')) fail('soft delete not sent');
if(lib.some((x)=>x.id==='S3')) fail('deleted song still in the list'); if(openId!==null) fail('open card not cleared'); if(loads!==1) fail('setlist reload after delete');
if(ops.some((b)=>has(b,'delete'))) fail('a hard delete was used for a song');
// ---------- setlist menu
items=[{id:'R1',position:1,songs:{id:'S1'}},{id:'R2',position:2.5,songs:{id:'S2'}}];
respond=(b)=>b.table==='setlists'&&has(b,'insert')?{id:'NEW'}:[];
ops=[]; bandLoads=0; await $('slDup').onclick();
const sl=ops.find((b)=>b.table==='setlists'&&has(b,'insert')); const slrow=sl.steps.find((s)=>s[0]==='insert')[1]; if(slrow.name!=='Saturday (copy)'||slrow.band_id!=='B1') fail('duplicate name '+JSON.stringify(slrow));
const ss=ops.find((b)=>b.table==='setlist_songs'&&has(b,'insert')); const rows=ss.steps.find((s)=>s[0]==='insert')[1];
if(rows.length!==2||rows[0].setlist_id!=='NEW'||rows[1].position!==2.5||rows[1].song_id!=='S2'||rows.some((r)=>r.band_id!=='B1')) fail('duplicate rows '+JSON.stringify(rows));
if(forcePick!=='NEW'||bandLoads!==1) fail('duplicate should switch to the new setlist (forcePick='+forcePick+', loads='+bandLoads+')');
askConfirm=false; ops=[]; await $('slDel').onclick(); if(ops.length) fail('setlist deleted without confirming');
askConfirm=true; ops=[]; openId='S1'; await $('slDel').onclick(); const d=ops.find((b)=>b.table==='setlists'&&has(b,'update'));
if(!d||!JSON.stringify(d.steps).includes('deleted_at')||!JSON.stringify(d.steps).includes('"L1"')) fail('setlist soft delete'); if(ops.some((b)=>has(b,'delete'))) fail('hard delete of a setlist'); if(openId!==null||closedGig!==1) fail('screen state after setlist delete');
$('slRename').value='  Friday  '; ops=[]; await $('slRenameBtn').onclick(); const rn=ops.find((b)=>b.table==='setlists'&&has(b,'update')); if(!JSON.stringify(rn.steps).includes('"Friday"')) fail('rename value');
$('slRename').value=''; ops=[]; await $('slRenameBtn').onclick(); if(ops.length) fail('empty rename should do nothing');
forcePick=null; await showSetlist('X9'); if(forcePick!=='X9') fail('showSetlist should set the pick');
// a created setlist is shown (this was broken when only the device memory was updated)
respond=(b)=>b.table==='setlists'&&has(b,'insert')?{id:'MADE'}:[]; forcePick=null; $('slNew').value='Gig 2'; bandLoads=0; await makeSetlist($('slNew')); if(forcePick!=='MADE'||bandLoads!==1) fail('created setlist should be shown');
// ---------- delete a band
store['c:ME:bands']='x'; store['c:ME:sl:B1']='y'; store['slB1']='z'; store['c:ME:sl:OTHER']='keep'; store['band']='B1';
askPrompt='wrong name'; ops=[]; await $('delBand').onclick(); if(ops.length) fail('band deleted with the wrong name'); if(!toasts.at(-1).includes('did not match')) fail('mismatch message');
askPrompt=null; ops=[]; await $('delBand').onclick(); if(ops.length) fail('cancelled prompt must do nothing');
askPrompt='Weaponized Conch'; respond=()=>[]; ops=[]; await $('delBand').onclick(); if(!toasts.at(-1).includes('Only the owner')) fail('non-owner message when nothing was deleted'); if(store['slB1']===undefined) fail('caches cleared although nothing was deleted');
respond=()=>[{id:'B1'}]; ops=[]; await $('delBand').onclick();
const del=ops.find((b)=>b.table==='bands'&&has(b,'delete')); if(!del||!JSON.stringify(del.steps).includes('"B1"')) fail('band delete not sent');
if(store['slB1']!==undefined||store['c:ME:sl:B1']!==undefined) fail('band caches not cleared'); if(store['c:ME:sl:OTHER']!=='keep') fail('other bands caches must stay'); if(store['band']!==undefined) fail('remembered band not cleared'); if(bandsReloaded!==1) fail('bands not reloaded');
if(!prompts[0].includes('cannot be undone')) fail('warning text');
console.log('song library, setlist menu and band delete checks passed');
"""
open('/tmp/v11test.mjs','w').write(pre+libblock+mk+menu+delb+body)
r=subprocess.run(['node','/tmp/v11test.mjs'],capture_output=True,text=True); print(r.stdout,r.stderr[:1800])
