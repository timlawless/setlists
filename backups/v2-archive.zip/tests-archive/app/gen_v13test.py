import re,subprocess
src=open('/tmp/v13.mjs',encoding='utf-8').read()
def between(a,b):
    i=src.index(a); j=src.index(b,i); return src[i:j]
authblock=between("let codeMode = null","$('signIn').onclick") if "$('signIn').onclick" in src[src.index("let codeMode = null"):] else between("let codeMode = null","$('signOut').onclick")
authblock=re.search(r"let codeMode = null.*?\$\('chPwGo'\)\.onclick = .*?\n\};\n",src,re.S).group(0)
statechg=re.search(r"sb\.auth\.onAuthStateChange\(\(e, s\) => \{.*?\n\}\);\n",src,re.S).group(0)
logo=re.search(r"const okLogo = .*?function drawLogo\(\) \{.*?\n\}\n",src,re.S).group(0)
savelogo=re.search(r"async function saveLogo\(dataUrl\) \{.*?\n\}\n",src,re.S).group(0)
pre=r"""
const els={}; const $=(id)=>(els[id] ||= {hidden:false,value:'',textContent:'',src:'',files:[]});
const toasts=[]; const say=(m)=>toasts.push(m);
const calls=[]; let nextAuth={};
const auth={};
for(const n of ['signUp','resetPasswordForEmail','signInWithOtp','verifyOtp','updateUser']) auth[n]=async(...a)=>{calls.push([n,...a]); const r=nextAuth[n]; if(r&&r.error) return {data:null,error:r.error}; return {data:(r&&r.data)||{},error:null}};
let handler; auth.onAuthStateChange=(f)=>{handler=f};
let dbCalls=[]; const sb={auth,from:(t)=>{const b={t,steps:[]}; for(const m of ['update','eq']) b[m]=(...a)=>{b.steps.push([m,...a]);return b}; b.then=(res)=>{dbCalls.push(b);res({data:null,error:null})}; return b}};
const must=async(p)=>{const r=await p; if(r.error){say(r.error.message); throw r.error;} return r.data;};
let user=null, bandId='B1', bandRows=[{bands:{id:'B1',name:'T',logo:null}}];
let rendered=0; const render=()=>{rendered++}, loadBands=()=>{loaded++}; let loaded=0;
globalThis.setTimeout=(f)=>f();
function fail(m){console.log('FAIL:',m);process.exit(1)}
"""
body=r"""
const has=(n)=>calls.filter((c)=>c[0]===n);
function reset(){calls.length=0;toasts.length=0;nextAuth={}; showPanel('pSign'); $('email').value='a@x.com'; $('pw').value='longenough1'; $('name').value='Ann'}
// ---- sign up
reset(); $('pw').value='short'; await $('signUp').onclick(); if(calls.length||!toasts.at(-1).includes('at least 8')) fail('short password should be refused');
reset(); $('email').value=''; await $('signUp').onclick(); if(calls.length) fail('missing email');
reset(); nextAuth.signUp={data:{session:{},user:{identities:[{}]}}}; await $('signUp').onclick(); if(!$('pSign').hidden===false||$('pCode').hidden===false) fail('signed-in sign up should not ask for a code');
reset(); nextAuth.signUp={data:{session:null,user:{identities:[{}]}}}; await $('signUp').onclick();
if($('pCode').hidden!==false||$('pSign').hidden!==true||codeMode!=='signup'||!$('codeHelp').textContent.includes('a@x.com')||$('codePw').hidden!==true) fail('sign-up should ask for the emailed code');
if(JSON.stringify(has('signUp')[0][1].options.data)!=='{"display_name":"Ann"}') fail('display name sent');
reset(); nextAuth.signUp={data:{session:null,user:{identities:[]}}}; await $('signUp').onclick(); if($('pCode').hidden===false||!toasts.at(-1).includes('already has an account')) fail('existing account should not wait for a code');
reset(); nextAuth.signUp={error:{message:'boom'}}; await $('signUp').onclick(); if($('pCode').hidden===false) fail('error should keep the form');
// confirming the sign-up code
reset(); nextAuth.signUp={data:{session:null,user:{identities:[{}]}}}; await $('signUp').onclick(); $('codeIn').value=' 123 456 '; await $('codeGo').onclick();
let v=has('verifyOtp')[0][1]; if(v.type!=='signup'||v.token!=='123456'||v.email!=='a@x.com') fail('verify sign-up '+JSON.stringify(v)); if(has('updateUser').length) fail('no password change on sign-up'); if($('pSign').hidden!==false) fail('back to the sign-in panel after success');
// ---- password reset by code
reset(); $('email').value=''; await $('forgot').onclick(); if(calls.length||!toasts.at(-1).includes('email address')) fail('forgot needs an email');
reset(); await $('forgot').onclick(); if(has('resetPasswordForEmail')[0][1]!=='a@x.com') fail('reset email requested'); if(codeMode!=='recovery'||$('codePw').hidden!==false||$('codeTitle').textContent!=='Reset your password') fail('reset panel');
$('codeIn').value='654321'; $('codePw1').value='short'; calls.length=0; await $('codeGo').onclick(); if(calls.length) fail('weak new password must not verify or save');
$('codePw1').value='brand-new-pw'; await $('codeGo').onclick();
if(has('verifyOtp')[0][1].type!=='recovery') fail('recovery type'); const up=has('updateUser')[0][1]; if(up.password!=='brand-new-pw') fail('new password sent'); if(calls.map((c)=>c[0]).join()!=='verifyOtp,updateUser') fail('order '+calls.map((c)=>c[0]));
reset(); await $('forgot').onclick(); $('codeIn').value='000000'; $('codePw1').value='brand-new-pw'; calls.length=0; nextAuth.verifyOtp={error:{message:'Token has expired or is invalid'}}; await $('codeGo').onclick();
if(has('updateUser').length) fail('a bad code must not change the password'); if(!toasts.at(-1).includes('invalid')) fail('bad code message');
// ---- sign-in code
reset(); await $('codeLogin').onclick(); const so=has('signInWithOtp')[0][1]; if(so.options.shouldCreateUser!==false||so.email!=='a@x.com') fail('code sign-in must not create accounts'); if(codeMode!=='email'||$('codePw').hidden!==true) fail('code panel for sign-in');
$('codeIn').value='111222'; await $('codeGo').onclick(); if(has('verifyOtp').at(-1)[1].type!=='email') fail('email code type');
$('codeCancel').onclick(); if($('pSign').hidden!==false||$('pCode').hidden!==true) fail('Back button');
// ---- change password while signed in
reset(); $('chPw').value='abc'; await $('chPwGo').onclick(); if(calls.length) fail('weak change refused'); $('chPw').value='a-good-password'; await $('chPwGo').onclick(); if(has('updateUser')[0][1].password!=='a-good-password'||$('chPw').value!=='') fail('change password');
// ---- reset link opened in the browser
"""+statechg+r"""
reset(); loaded=0; rendered=0; user=null; handler('PASSWORD_RECOVERY',{user:{id:'U1',email:'a@x.com'}});
if(recovering!==true||$('pNew').hidden!==false||$('pSign').hidden!==true) fail('recovery link should show the new-password panel'); if(loaded!==1) fail('signed-in user loads');
$('newPw').value='tiny'; calls.length=0; await $('newPwGo').onclick(); if(calls.length||recovering!==true) fail('weak password from link refused');
$('newPw').value='a-long-new-password'; rendered=0; await $('newPwGo').onclick(); if(has('updateUser')[0][1].password!=='a-long-new-password'||recovering!==false||rendered<1||$('pSign').hidden!==false) fail('save from link');
loaded=0; handler('SIGNED_IN',{user:{id:'U1'}}); if(loaded!==0) fail('same person returning to the tab must not reload');
handler('SIGNED_OUT',null); if(loaded!==1) fail('sign out reloads');
console.log('sign-in, reset and code checks passed');
// ---- logo helpers
"""+logo+savelogo+r"""
const PNG='data:image/png;base64,iVBORw0KGgo=';
if(!okLogo(PNG)||okLogo('javascript:alert(1)')||okLogo('data:image/svg+xml;base64,AAAA')||okLogo(null)||okLogo('data:image/png;base64,AA"onerror="x')) fail('okLogo');
let [w,h]=fitSize(1000,500,256); if(w!==256||h!==128) fail('fit wide '+w+h); [w,h]=fitSize(100,300,256); if(w!==85||h!==256) fail('fit tall '+w+','+h); [w,h]=fitSize(50,40,256); if(w!==50||h!==40) fail('never upscale'); [w,h]=fitSize(0,0,256); if(w<1||h<1) fail('zero size guard');
bandRows[0].bands.logo=PNG; drawLogo(); if($('logoImg').hidden||$('logoImg').src!==PNG||$('logoPrev').hidden||$('logoRemove').hidden) fail('logo shown');
bandRows[0].bands.logo='data:text/html;base64,PHNjcmlwdD4='; drawLogo(); if(!$('logoImg').hidden||!$('logoRemove').hidden) fail('an unsafe logo value must not be shown');
bandRows[0].bands.logo=null; drawLogo(); if(!$('logoImg').hidden) fail('no logo hides the image');
dbCalls.length=0; await saveLogo(PNG); const b=dbCalls[0]; if(b.t!=='bands'||!JSON.stringify(b.steps).includes('"logo"')||!JSON.stringify(b.steps).includes('"B1"')) fail('save logo call'); if(bandRows[0].bands.logo!==PNG||$('logoImg').hidden) fail('logo kept locally');
await saveLogo(null); if(bandRows[0].bands.logo!==null||!$('logoImg').hidden) fail('remove logo');
console.log('logo helper checks passed');
"""
open('/tmp/v13test.mjs','w').write(pre+authblock+body)
r=subprocess.run(['node','/tmp/v13test.mjs'],capture_output=True,text=True); print(r.stdout,r.stderr[:1800])
