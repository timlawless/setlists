
const els={}; const mk=()=>({hidden:false,textContent:'',innerHTML:'',value:'',dataset:{},contains:()=>false,addEventListener(){},showModal(){this.opened=true},close(){this.closed=true},classList:{add(){},remove(){}}});
const $=(id)=>(els[id] ||= mk());
const window={addEventListener(){}}; const document={addEventListener(){},activeElement:null}; const setInterval=()=>0; const navigator={onLine:false};
const store={}; const localStorage={getItem:(k)=>(k in store?store[k]:null),setItem:(k,v)=>{store[k]=String(v)},removeItem:(k)=>{delete store[k]}};
let user={id:'U1'}, items=[], setlistId='L1', bandId='B1', openId=null, matches=[]; const ck=(k)=>`c:${user.id}:${k}`;
const esc=(s)=>String(s??'').replace(/[&<>"']/g,(c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const toasts=[]; const say=(m)=>toasts.push(m); let renders=0; const render=()=>{renders++}; const loadSetlist=async()=>{}; const loadLinks=()=>{}; const canEdit=()=>true;
const norm=(u)=>{u=(u||'').trim();return !u?null:/^https?:\/\//i.test(u)?u:'https://'+u}; const toggleClick=async()=>{}; globalThis.confirm=()=>true;
// the network is down: every call fails like a lost connection
const lost={data:null,error:{message:'TypeError: Failed to fetch',code:''}};
const b=()=>{const q={};for(const m of ['select','insert','update','eq','is','order','limit','maybeSingle','single'])q[m]=()=>q;q.then=(r)=>r(lost);return q};
const sb={from:b}; const must=async(p)=>{const r=await p;if(r.error)throw r.error;return r.data};
function fail(m){console.log('FAIL:',m);process.exit(1)} const ok=(c,m)=>{if(!c)fail(m)};
async function cached(k, fn) { // read from Supabase, keep a copy for offline viewing
  if (queue.length) { const mine = localStorage.getItem(k); if (mine) return JSON.parse(mine); } // changes are waiting to sync: show the local copy
  try { const v = await fn(); localStorage.setItem(k, JSON.stringify(v)); return v; }
  catch (e) { const c = localStorage.getItem(k); if (c) { say('Offline: showing the saved copy'); return JSON.parse(c); } throw e; }
}

// ---- offline editing: changes are saved on the device first and sent when there is a connection
let queue = [], issues = [], flushing = false, pendingReload = false;
const qk = () => `q:${user.id}`, ik = () => `qi:${user.id}`;
const uuid = () => crypto.randomUUID();
const same = (a, b) => String(a ?? '') === String(b ?? '');
function loadQ() { try { queue = JSON.parse(localStorage.getItem(qk()) || '[]'); issues = JSON.parse(localStorage.getItem(ik()) || '[]'); } catch { queue = []; issues = []; } updateChip(); }
function saveQ() { try { localStorage.setItem(qk(), JSON.stringify(queue)); localStorage.setItem(ik(), JSON.stringify(issues)); } catch {} updateChip(); }
function enqueue(...ops) {
  const now = new Date().toISOString();
  ops.forEach((o) => queue.push({ ...o, qid: uuid(), at: now, offline: !navigator.onLine }));
  saveQ(); flush();
}
const persist = (key, v) => { try { localStorage.setItem(ck(key), JSON.stringify(v)); } catch {} };
const persistItems = () => persist('items:' + setlistId, items);
const transient = (e) => !e.code || e.code === 'PGRST301' || /jwt/i.test(e.message || '');
const verdict = (e, dupOk) => (!e ? 'done' : dupOk && e.code === '23505' ? 'done' : transient(e) ? 'retry' : { fail: e.message });
async function upd(table, vals, col, val) {
  const r = await sb.from(table).update(vals).eq(col, val).select('id');
  if (r.error) return verdict(r.error);
  return r.data.length ? 'done' : { fail: 'That item no longer exists, or you no longer have permission to change it' };
}
async function runSongEdit(op) {
  for (let tries = 0; tries < 3; tries++) {
    const cur = await sb.from('songs').select('*').eq('id', op.sid).maybeSingle();
    if (cur.error) return verdict(cur.error);
    const row = cur.data;
    if (!row || row.deleted_at) return { fail: 'This song was deleted by someone else' };
    const apply = {}, conflicts = [];
    for (const [k, v] of Object.entries(op.set)) {
      if (same(row[k], v)) continue;
      if (same(row[k], op.base[k])) apply[k] = v; else conflicts.push({ field: k, mine: v, theirs: row[k] });
    }
    if (Object.keys(apply).length) {
      const r = await sb.from('songs').update({ ...apply, change_note: op.note || (op.offline ? 'Edited offline' : null) }).eq('id', op.sid).eq('updated_at', row.updated_at).select('id');
      if (r.error) return verdict(r.error);
      if (!r.data.length) continue; // someone changed the song meanwhile: merge again
    }
    return conflicts.length ? { conflicts } : 'done';
  }
  return 'retry';
}
async function runOp(op) {
  switch (op.t) {
    case 'songNew': return verdict((await sb.from('songs').insert(op.row)).error, true);
    case 'slAdd': return verdict((await sb.from('setlist_songs').insert(op.row)).error, true);
    case 'linkAdd': return verdict((await sb.from('song_links').insert(op.row)).error, true);
    case 'slPos': return upd('setlist_songs', { position: op.position }, 'id', op.id);
    case 'slRemove': return upd('setlist_songs', { deleted_at: op.at }, 'id', op.id);
    case 'songDel': return upd('songs', { deleted_at: op.at }, 'id', op.sid);
    case 'linkDel': return upd('song_links', { deleted_at: op.at }, 'id', op.id);
    case 'song': return runSongEdit(op);
  }
  return { fail: 'Unknown change' };
}
async function flush(reload = true) {
  if (flushing || !user || !queue.length) return;
  flushing = true; let did = false;
  try {
    while (queue.length) {
      let r; try { r = await runOp(queue[0]); } catch { r = 'retry'; }
      if (r === 'retry') break; // no connection: try again later
      const op = queue.shift(); did = true;
      if (r !== 'done') issues.push({ ...op, ...r });
      saveQ();
    }
  } finally { flushing = false; saveQ(); }
  if (did && !queue.length && reload) reloadSoon();
}
function reloadSoon() { // refresh from the server, but not while someone is typing in a song
  if ($('list').contains(document.activeElement)) { pendingReload = true; return; }
  pendingReload = false; if (user && setlistId) loadSetlist();
}
function describe(o) {
  const t = `“${o.label || 'song'}”`;
  return ({ song: `Edit ${t}: ${Object.keys(o.set || {}).join(', ')}`, songNew: `New song ${t}`, songDel: `Delete ${t}`, slAdd: `Add ${t} to the setlist`, slPos: `Move ${t} in the setlist`, slRemove: `Remove ${t} from the setlist`, linkAdd: `Add a link to ${t}`, linkDel: `Remove a link from ${t}` })[o.t] || 'Change';
}
function updateChip() {
  const c = $('syncChip'); if (!c) return;
  c.hidden = !user || !(queue.length || issues.length || !navigator.onLine);
  c.textContent = issues.length ? `Check sync (${issues.length})` : queue.length ? `${queue.length} waiting` : 'Offline';
}
function drawSync() {
  $('syncState').textContent = !navigator.onLine ? 'You are offline. Changes are saved on this device and will sync when you are back online.' : queue.length ? 'Changes are waiting to sync.' : 'Everything is synced.';
  $('syncPending').innerHTML = queue.map((o) => `<li><small>${esc(describe(o))}</small></li>`).join('') || '<li><small>Nothing waiting</small></li>';
  $('syncIssues').innerHTML = issues.map((o) => (o.conflicts
    ? `<li><span>${esc(describe(o))}<br>${o.conflicts.map((c) => `<small>${esc(c.field)}: yours “${esc(String(c.mine ?? ''))}”, theirs “${esc(String(c.theirs ?? ''))}”</small>`).join('<br>')}</span><span><button data-mine="${o.qid}">Use mine</button> <button data-theirs="${o.qid}">Keep theirs</button></span></li>`
    : `<li><span>${esc(describe(o))}<br><small>Not saved: ${esc(o.fail || 'unknown problem')}</small></span><button data-dis="${o.qid}">Dismiss</button></li>`)).join('') || '<li><small>No problems</small></li>';
}
$('syncChip').onclick = () => { drawSync(); $('syncDlg').showModal(); };
$('syncClose').onclick = () => $('syncDlg').close();
$('syncNow').onclick = async () => { await flush(); drawSync(); };
$('syncIssues').onclick = (e) => {
  const d = e.target.dataset, o = issues.find((x) => x.qid === (d.mine || d.theirs || d.dis)); if (!o) return;
  issues = issues.filter((x) => x !== o);
  if (d.mine) queue.push({ t: 'song', sid: o.sid, label: o.label, qid: uuid(), at: new Date().toISOString(), offline: false, note: 'Offline edit kept over a conflicting change', base: Object.fromEntries(o.conflicts.map((c) => [c.field, c.theirs])), set: Object.fromEntries(o.conflicts.map((c) => [c.field, c.mine])) });
  saveQ(); drawSync(); if (d.mine) flush(); else reloadSoon();
};
window.addEventListener('online', () => { updateChip(); flush(); });
window.addEventListener('offline', updateChip);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') flush(); });
setInterval(() => { updateChip(); if (queue.length) flush(); }, 20000);
$('list').addEventListener('focusout', () => setTimeout(() => { if (pendingReload && !$('list').contains(document.activeElement)) reloadSoon(); }, 300));

$('list').onclick = async (e) => {
  const b = e.target.closest('button[data-a]'); if (!b) return;
  const art = b.closest('article'), id = art.dataset.id, sid = art.dataset.sid, i = items.findIndex((x) => x.id === id), a = b.dataset.a;
  if (['up', 'down', 'save', 'remove', 'delsong', 'lookup', 'sfget', 'usematch', 'addlink', 'dellink'].includes(a) && !canEdit()) return say('You have view-only access in this band');
  try {
    if (a === 'toggle') { openId = openId === sid ? null : sid; render(); }
    else if (a === 'up' || a === 'down') {
      const j = i + (a === 'up' ? -1 : 1); if (j < 0 || j >= items.length) return; const x = items[i], y = items[j], px = x.position, py = y.position;
      x.position = py; y.position = px; items.sort((m, n) => m.position - n.position);
      persistItems(); enqueue({ t: 'slPos', id: x.id, position: py, label: x.songs.title }, { t: 'slPos', id: y.id, position: px, label: y.songs.title }); render();
    }
    else if (a === 'play') { await toggleClick(items[i].songs); }
    else if (a === 'save') {
      const p = {}; art.querySelectorAll('[data-f]').forEach((el) => (p[el.dataset.f] = el.value.trim()));
      if (!p.title) return say('A title is needed');
      const nv = { title: p.title, artist: p.artist, version_label: p.version_label, time_signature: p.time_signature || '4/4', bpm: +p.bpm || null, musical_key: p.musical_key || null, chords: p.chords, root_notes: p.root_notes, notes: p.notes, lyrics_url: norm(p.lyrics_url), youtube_url: norm(p.youtube_url), ...(art.dataset.ref ? { catalog_ref: art.dataset.ref } : {}) };
      const song = items[i].songs, set = {}, base = {};
      Object.keys(nv).forEach((k) => { if (!same(song[k], nv[k])) { set[k] = nv[k]; base[k] = song[k] ?? null; } });
      if (!Object.keys(set).length) return say('Nothing has changed');
      Object.assign(song, set); const l = libFor === bandId ? lib.find((x) => x.id === sid) : null; if (l) Object.assign(l, set);
      persistItems(); persistLib();
      enqueue({ t: 'song', sid, label: song.title, base, set, note: art.querySelector('[data-r="reason"]').value.trim() || null });
      say(navigator.onLine ? 'Saved' : 'Saved on this device. It will sync when you are back online.'); render();
    }
    else if (a === 'remove') { if (confirm('Remove this song from the setlist?')) { const x = items[i]; items.splice(i, 1); openId = null; persistItems(); enqueue({ t: 'slRemove', id: x.id, label: x.songs.title }); render(); } }
    else if (a === 'delsong') {
      const t = items[i].songs.title;
      if (!confirm(`Delete “${t}” from this band? It will disappear from every setlist.`)) return;
      items = items.filter((x) => x.songs.id !== sid); if (libFor === bandId) lib = lib.filter((x) => x.id !== sid);
      persistItems(); persistLib(); enqueue({ t: 'songDel', sid, label: t }); openId = null; say('Song deleted'); render();
    }
    else if (a === 'hist') {
      const [rows, mem] = await Promise.all([
        must(sb.from('change_log').select('changed_at,changed_by,op,old_data,new_data,reason').eq('table_name', 'songs').eq('row_id', sid).order('changed_at', { ascending: false }).limit(20)),
        must(sb.from('band_members').select('user_id,profiles(display_name)').eq('band_id', bandId)),
      ]);
      const who = Object.fromEntries(mem.map((m) => [m.user_id, m.profiles?.display_name || 'Someone']));
      const LABEL = { title: 'title', artist: 'artist', version_label: 'version', bpm: 'BPM', musical_key: 'key', time_signature: 'time signature', chords: 'chords', root_notes: 'root notes', notes: 'notes', lyrics_url: 'lyrics link', youtube_url: 'YouTube link', deleted_at: 'deleted' };
      const short = (v) => { const t = v == null || v === '' ? 'empty' : String(v); return t.length > 30 ? t.slice(0, 30) + '…' : t; };
      const diff = (r) => {
        if (r.op === 'INSERT') return 'Song added';
        const o = r.old_data || {}, n = r.new_data || {};
        const ch = Object.keys(LABEL).filter((k) => JSON.stringify(o[k]) !== JSON.stringify(n[k]));
        return ch.map((k) => (k === 'chords' || k === 'root_notes' || k === 'notes' || k.endsWith('_url') ? LABEL[k] + ' edited' : `${LABEL[k]}: ${short(o[k])} → ${short(n[k])}`)).join('; ') || 'Edited';
      };
      art.querySelector('[data-hist]').innerHTML = rows.map((r) => `<li><span>${esc(diff(r))}${r.reason ? `<br><small>Reason: ${esc(r.reason)}</small>` : ''}</span><small style="text-align:right">${esc(who[r.changed_by] || 'Someone')}<br>${esc(new Date(r.changed_at).toLocaleString())}</small></li>`).join('') || '<li><small>No history yet</small></li>';
    }
    else if (a === 'lookup') {
      const val = (k) => art.querySelector(`[data-f="${k}"]`).value.trim(), title = val('title'), artist = val('artist');
      if (!title) return say('Type a title first');
      const ul = art.querySelector('[data-lookup]'); ul.innerHTML = '<li><small>Searching…</small></li>';
      const { data, error } = await sb.functions.invoke('lookup-song', { body: { title, artist } });
      if (error) { let m = error.message; try { m = (await error.context.json()).error || m; } catch {} ul.innerHTML = ''; return say('Lookup failed: ' + m); }
      matches = data?.results || []; cands = data?.candidates || []; drawLookup(ul);
    }
    else if (a === 'sfget') {
      const c = cands[+b.dataset.k]; if (!c) return;
      b.disabled = true; b.textContent = 'Getting…';
      const { data, error } = await sb.functions.invoke('lookup-song', { body: { isrc: c.id } });
      if (error) { let m = error.message; try { m = (await error.context.json()).error || m; } catch {} b.disabled = false; b.textContent = 'Get tempo and key'; return say('Lookup failed: ' + m); }
      const m = data?.results?.[0];
      if (!m) { b.disabled = false; b.textContent = 'Not available'; return say(data?.note || 'No tempo and key found for that recording.'); }
      matches.push({ ...m, title: m.title || c.title, artist: m.artist || c.artist }); cands.splice(+b.dataset.k, 1);
      drawLookup(art.querySelector('[data-lookup]'));
    }
    else if (a === 'usematch') {
      const m = matches[+b.dataset.k]; if (!m) return;
      const set = (k, v) => { if (v) art.querySelector(`[data-f="${k}"]`).value = v; };
      set('bpm', m.tempo); set('musical_key', m.key_of); set('time_signature', m.time_sig); set('version_label', m.artist);
      if (!art.querySelector('[data-f="artist"]').value.trim()) set('artist', m.artist);
      art.dataset.ref = m.id || ''; say('Filled in. Tap Save changes to keep it.');
    }
    else if (a === 'addlink') {
      const g = (k) => art.querySelector(`[data-l="${k}"]`).value.trim(), url = norm(g('url')); if (!url) return say('Add a link first');
      const row = { id: uuid(), band_id: bandId, song_id: sid, kind: g('kind'), label: g('label'), url, added_by: user.id };
      const lk = ck('links:' + sid), have = localStorage.getItem(lk);
      if (have) persist('links:' + sid, [...JSON.parse(have), { id: row.id, kind: row.kind, label: row.label, url }]);
      enqueue({ t: 'linkAdd', row, label: items[i].songs.title });
      art.querySelector('[data-l="url"]').value = ''; art.querySelector('[data-l="label"]').value = ''; loadLinks(sid);
    }
    else if (a === 'dellink') {
      const lk = ck('links:' + sid), have = localStorage.getItem(lk);
      if (have) persist('links:' + sid, JSON.parse(have).filter((x) => x.id !== b.dataset.lid));
      enqueue({ t: 'linkDel', id: b.dataset.lid, label: items[i].songs.title }); loadLinks(sid);
    }
  } catch { /* the error toast has already been shown */ }
};
// ---- song library: search, add to the setlist, delete
let lib = [], libFor = null;
const persistLib = () => { if (libFor === bandId) persist('lib:' + bandId, lib); };
function addToSetlist(song, keepOpen) {
  const position = (items.length ? Math.max(...items.map((x) => x.position)) : 0) + 1;
  const row = { id: uuid(), band_id: bandId, setlist_id: setlistId, song_id: song.id, position };
  items.push({ id: row.id, position, songs: song }); items.sort((m, n) => m.position - n.position);
  persistItems(); enqueue({ t: 'slAdd', row, label: song.title });
  if (!keepOpen) $('addDlg').close();
  render(); if (keepOpen) drawLib();
}
function drawLib() {
  const q = $('songSearch').value.trim().toLowerCase(), used = new Set(items.map((x) => x.songs.id));
  const rows = lib.filter((x) => !q || `${x.title} ${x.artist}`.toLowerCase().includes(q));
  $('libList').innerHTML = rows.map((x) => `<li><span><b>${esc(x.title)}</b><br><small>${esc([x.artist, x.bpm && x.bpm + ' bpm', x.musical_key].filter(Boolean).join(' · '))}</small></span><span>${used.has(x.id) ? '<span class="pill">In setlist</span>' : `<button data-add="${x.id}" class="primary">Add</button>`} <button data-del="${x.id}">Delete</button></span></li>`).join('') || '<li><small>No songs found</small></li>';
}
async function openLibrary() {
  if (!setlistId) return say('Create or pick a setlist first');
  try {
    lib = await cached(ck('lib:' + bandId), () => must(sb.from('songs').select('*').eq('band_id', bandId).is('deleted_at', null).order('title')));
    libFor = bandId; $('songSearch').value = ''; drawLib(); $('addDlg').showModal();
  } catch {}
}
$('addBtn').onclick = openLibrary;
$('songSearch').oninput = drawLib;
$('addClose').onclick = () => $('addDlg').close();
$('libList').onclick = (e) => {
  const add = e.target.dataset.add, del = e.target.dataset.del;
  if (add) { const song = lib.find((y) => y.id === add); if (song) addToSetlist(song, true); }
  else if (del) {
    const x = lib.find((y) => y.id === del);
    if (!x || !confirm(`Delete “${x.title}” from this band? It will disappear from every setlist.`)) return;
    lib = lib.filter((y) => y.id !== del); items = items.filter((y) => y.songs.id !== del); if (openId === del) openId = null;
    persistLib(); persistItems(); enqueue({ t: 'songDel', sid: del, label: x.title }); say('Song deleted'); drawLib(); render();
  }
};
$('addNew').onclick = () => {
  const title = $('nTitle').value.trim(); if (!title) return say('A title is needed');
  if (!setlistId) return say('Create or pick a setlist first');
  const song = { id: uuid(), band_id: bandId, title, artist: $('nArtist').value.trim(), version_label: '', bpm: +$('nBpm').value || null, musical_key: $('nKey').value.trim() || null, time_signature: '4/4', chords: '', root_notes: '', notes: '', lyrics_url: null, youtube_url: null, created_by: user.id };
  enqueue({ t: 'songNew', label: title, row: { id: song.id, band_id: bandId, title, artist: song.artist, bpm: song.bpm, musical_key: song.musical_key, created_by: user.id } });
  if (libFor === bandId) { lib.push(song); lib.sort((m, n) => m.title.localeCompare(n.title)); persistLib(); }
  ['nTitle', 'nArtist', 'nBpm', 'nKey'].forEach((k) => ($(k).value = '')); addToSetlist(song);
};


const song=(id,t,bpm)=>({id,band_id:'B1',title:t,artist:'',version_label:'',bpm,musical_key:'E',time_signature:'4/4',chords:'',root_notes:'',notes:'',lyrics_url:null,youtube_url:null});
items=[{id:'R1',position:1,songs:song('S1','One',100)},{id:'R2',position:2,songs:song('S2','Two',90)}];
const fields=(over)=>Object.entries({title:'One',artist:'',version_label:'',time_signature:'4/4',bpm:'100',musical_key:'E',chords:'',root_notes:'',notes:'',lyrics_url:'',youtube_url:'',...over}).map(([f,v])=>({dataset:{f},value:v}));
const art=(id,sid,extra={})=>({dataset:{id,sid},querySelectorAll:()=>extra.fields||[],querySelector:(sel)=>(extra.q&&extra.q[sel])||{value:''}});
const click=async(a,article,extra={})=>{const btn={dataset:{a,...extra},closest:()=>article};await els.list.onclick({target:{closest:()=>btn}})};
const wait=()=>new Promise((r)=>setTimeout(r,20));
loadQ(); queue=[]; issues=[];
// save
await click('save',art('R1','S1',{fields:fields({bpm:'110',notes:'n'}),q:{'[data-r="reason"]':{value:'why'}}})); await wait();
ok(queue.length===1&&queue[0].t==='song','one edit queued'); const op=queue[0];
ok(JSON.stringify(op.set)==='{"bpm":110,"notes":"n"}'&&JSON.stringify(op.base)==='{"bpm":100,"notes":""}'&&op.note==='why'&&op.sid==='S1','only changed fields, with the values they had: '+JSON.stringify(op));
ok(items[0].songs.bpm===110&&JSON.parse(store['c:U1:items:L1'])[0].songs.bpm===110,'screen and saved copy updated straight away');
ok(toasts.at(-1).includes('saved on this device')||toasts.at(-1).includes('Saved on this device'),'offline message: '+toasts.at(-1));
queue=[]; await click('save',art('R1','S1',{fields:fields({bpm:'110',notes:'n'})})); ok(queue.length===0&&toasts.at(-1)==='Nothing has changed','no change, nothing queued');
await click('save',art('R1','S1',{fields:fields({title:''})})); ok(queue.length===0&&toasts.at(-1)==='A title is needed','title still required');
// reorder
queue=[]; await click('down',art('R1','S1')); await wait();
ok(items[0].id==='R2'&&items[1].id==='R1','order changed on screen'); ok(queue.length===2&&queue.every((o)=>o.t==='slPos')&&queue.find((o)=>o.id==='R1').position===2&&queue.find((o)=>o.id==='R2').position===1,'two position changes queued');
ok(JSON.parse(store['c:U1:items:L1'])[0].id==='R2','saved copy reordered');
await click('up',art('R2','S2')); ok(items[0].id==='R2','first row cannot move up'); // R2 is first now
// remove from setlist
queue=[]; await click('remove',art('R2','S2')); ok(items.length===1&&items[0].id==='R1'&&queue[0].t==='slRemove'&&queue[0].id==='R2','removed from setlist');
// delete the song
items=[{id:'R1',position:1,songs:song('S1','One',100)},{id:'R2',position:2,songs:song('S2','Two',90)}]; queue=[];
await click('delsong',art('R2','S2')); ok(items.length===1&&queue[0].t==='songDel'&&queue[0].sid==='S2','song deleted everywhere on screen');
// links: with and without a saved copy
queue=[]; store['c:U1:links:S1']=JSON.stringify([{id:'old',kind:'tab',label:'Old',url:'https://e.com/o'}]);
await click('addlink',art('R1','S1',{q:{'[data-l="kind"]':{value:'tab'},'[data-l="label"]':{value:'New'},'[data-l="url"]':{value:'e.com/n'}}})); await wait();
const lk=JSON.parse(store['c:U1:links:S1']); ok(lk.length===2&&lk[1].url==='https://e.com/n'&&queue[0].t==='linkAdd'&&queue[0].row.id===lk[1].id&&queue[0].row.url==='https://e.com/n','link shown and queued');
await click('dellink',art('R1','S1'),{lid:'old'}); ok(JSON.parse(store['c:U1:links:S1']).every((x)=>x.id!=='old')&&queue.at(-1).t==='linkDel'&&queue.at(-1).id==='old','link removed and queued');
queue=[]; delete store['c:U1:links:S3']; items.push({id:'R9',position:5,songs:song('S3','Three',80)});
await click('addlink',art('R9','S3',{q:{'[data-l="kind"]':{value:'tab'},'[data-l="label"]':{value:''},'[data-l="url"]':{value:'x.com'}}})); ok(store['c:U1:links:S3']===undefined&&queue.length===1,'no saved list means no half list is stored');
await click('addlink',art('R9','S3',{q:{'[data-l="url"]':{value:''},'[data-l="kind"]':{value:'tab'},'[data-l="label"]':{value:''}}})); ok(toasts.at(-1)==='Add a link first','empty link refused');

// library: open from the saved copy while offline
items=[{id:'R1',position:1,songs:song('S1','One',100)}]; queue=[];
store['c:U1:lib:B1']=JSON.stringify([song('S1','One',100),song('S2','Two',90),song('S3','Three',80)]);
await els.addBtn.onclick(); ok(lib.length===3&&libFor==='B1'&&els.addDlg.opened===true,'library opens offline from the saved copy');
ok(els.libList.innerHTML.includes('In setlist')&&(els.libList.innerHTML.match(/data-add=/g)||[]).length===2,'in-setlist label and add buttons');
els.libList.onclick({target:{dataset:{add:'S3'}}}); ok(items.length===2&&items[1].songs.id==='S3'&&items[1].position===2&&queue[0].t==='slAdd'&&queue[0].row.song_id==='S3'&&queue[0].row.position===2,'song added to the setlist locally and queued');
ok(!els.addDlg.closed,'dialog stays open when adding from the list'); ok(JSON.parse(store['c:U1:items:L1']).length===2,'saved copy updated');
// create a new song offline
queue=[]; els.nTitle=mk(); els.nTitle.value='Brand New'; els.nArtist=mk(); els.nArtist.value='Me'; els.nBpm=mk(); els.nBpm.value='88'; els.nKey=mk(); els.nKey.value='A';
els.addNew.onclick(); ok(queue.length===2&&queue[0].t==='songNew'&&queue[1].t==='slAdd'&&queue[1].row.song_id===queue[0].row.id,'new song then its setlist entry, in that order');
ok(queue[0].row.title==='Brand New'&&queue[0].row.bpm===88&&queue[0].row.musical_key==='A'&&queue[0].row.created_by==='U1','new song fields'); ok(items.at(-1).songs.title==='Brand New'&&lib.some((x)=>x.title==='Brand New'),'shown at once'); ok(els.nTitle.value==='','form cleared'); ok(els.addDlg.closed===true,'dialog closes after create');
els.nTitle.value=''; queue=[]; els.addNew.onclick(); ok(queue.length===0&&toasts.at(-1)==='A title is needed','title required');
// delete from the library
queue=[]; els.libList.onclick({target:{dataset:{del:'S2'}}}); ok(!lib.some((x)=>x.id==='S2')&&queue[0].t==='songDel'&&queue[0].sid==='S2','library delete queued'); ok(JSON.parse(store['c:U1:lib:B1']).every((x)=>x.id!=='S2'),'saved library updated');
// while changes wait, the saved copy is shown instead of the server
queue=[{t:'songDel'}]; store['c:U1:probe']=JSON.stringify({from:'device'}); const got=await cached(ck('probe'),async()=>({from:'server'})); ok(got.from==='device','local copy shown while changes wait');
queue=[]; const got2=await cached(ck('probe'),async()=>({from:'server'})); ok(got2.from==='server','server shown when nothing is waiting');
const gone=await cached(ck('missing'),async()=>({from:'server'})); ok(gone.from==='server','no saved copy: fall back to the server');
console.log('offline screen actions checks passed');
