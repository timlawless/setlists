const flashAllowed = (bpm, beatInBar, perBar) => bpm <= 180 || (beatInBar === 0 && bpm / 60 / perBar <= 3);

function fail(m){console.log('FAIL:',m);process.exit(1)}
// the rule from the earlier design
if(!flashAllowed(120,2,4)||!flashAllowed(180,1,4)||flashAllowed(181,1,4)||!flashAllowed(181,0,4)||!flashAllowed(300,0,4)) fail('basic cases');
// never more than three full-screen flashes a second, for every tempo and every time signature
let worst=0;
for(let bpm=20;bpm<=300;bpm++) for(let perBar=1;perBar<=16;perBar++){
  let n=0; for(let b=0;b<perBar;b++) if(flashAllowed(bpm,b,perBar)) n++;
  const perSecond=n/(perBar*60/bpm); worst=Math.max(worst,perSecond);
  if(perSecond>3+1e-9) fail(`too many flashes at ${bpm} BPM in ${perBar}: ${perSecond}`);
}
// consecutive flashes are spaced at least a third of a second apart
for(let bpm=181;bpm<=300;bpm++) for(let perBar=1;perBar<=16;perBar++){ if(flashAllowed(bpm,0,perBar) && (perBar*60/bpm)<1/3-1e-9) fail('spacing '+bpm+' '+perBar); }
console.log('flash rule checks passed; worst case',worst.toFixed(2),'flashes per second');
