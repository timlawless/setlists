
import pg from 'pg';
pg.types.setTypeParser(1184, (v) => v);
const pool = new pg.Pool({ database: 't1', user: 'postgres', host: '/var/run/postgresql', max: 4 });
const U = { owner: '00000000-0000-0000-0000-000000000001', admin: '00000000-0000-0000-0000-000000000002', editor: '00000000-0000-0000-0000-000000000003', viewer: '00000000-0000-0000-0000-000000000004' };
const net = { offline: false, uid: U.editor, hook: null, offlineAfter: null, count: 0 };
class Q {
  constructor(t) { this.table = t; this.act = 'select'; this.cols = '*'; this.f = []; this.ord = null; this.lim = null; this.sel = false; this.one = null; }
  select(c = '*') { if (this.act === 'select') this.cols = c; else { this.sel = true; } return this; }
  insert(r) { this.act = 'insert'; this.rows = Array.isArray(r) ? r : [r]; return this; }
  update(v) { this.act = 'update'; this.vals = v; return this; }
  eq(c, v) { this.f.push([c, '=', v]); return this; }
  is(c, v) { this.f.push([c, 'is', v]); return this; }
  order(c, o) { this.ord = [c, o && o.ascending === false ? 'desc' : 'asc']; return this; }
  limit(n) { this.lim = n; return this; }
  maybeSingle() { this.one = 'maybe'; return this; }
  single() { this.one = 'single'; return this; }
  then(res, rej) { exec(this).then(res, rej); }
}
async function exec(q) {
  if (net.offline) return { data: null, error: { message: 'TypeError: Failed to fetch', code: '' } };
  const params = []; const P = (v) => { params.push(v); return '$' + params.length; }; let sql;
  if (q.act === 'update') { const keys = Object.keys(q.vals); const set = keys.map((k) => `${k} = ${P(q.vals[k])}`).join(','); const where = q.f.map(([c, op, v]) => (op === 'is' ? `${c} is null` : `${c} = ${P(v)}`)).join(' and '); sql = `update public.${q.table} set ${set}${where ? ' where ' + where : ''} returning *`; }
  else if (q.act === 'insert') { const cols = Object.keys(q.rows[0]); sql = `insert into public.${q.table} (${cols.join(',')}) values ${q.rows.map((r) => `(${cols.map((c) => P(r[c])).join(',')})`).join(',')} returning *`; }
  else { const where = q.f.map(([c, op, v]) => (op === 'is' ? `${c} is null` : `${c} = ${P(v)}`)).join(' and '); sql = `select ${q.cols} from public.${q.table}${where ? ' where ' + where : ''}${q.ord ? ` order by ${q.ord[0]} ${q.ord[1]}` : ''}${q.lim ? ` limit ${q.lim}` : ''}`; }
  const c = await pool.connect();
  try {
    await c.query('begin'); await c.query('set local role authenticated'); await c.query("select set_config('request.jwt.claim.sub', $1, true)", [net.uid]);
    const r = await c.query(sql, params); await c.query('commit');
    net.count++; if (net.offlineAfter && net.count >= net.offlineAfter) net.offline = true;
    let data = r.rows;
    if (q.act !== 'select' && !q.sel) data = null;
    if (q.one === 'maybe') { if (r.rows.length > 1) return { data: null, error: { code: 'PGRST116', message: 'multiple rows' } }; data = r.rows[0] || null; }
    if (q.one === 'single') { if (r.rows.length !== 1) return { data: null, error: { code: 'PGRST116', message: 'not exactly one row' } }; data = r.rows[0]; }
    if (q.act === 'select' && q.table === 'songs' && q.one === 'maybe' && net.hook) { const h = net.hook; net.hook = null; await h(); }
    return { data, error: null };
  } catch (e) { try { await c.query('rollback'); } catch {} return { data: null, error: { code: e.code || '', message: e.message } }; }
  finally { c.release(); }
}
const sb = { from: (t) => new Q(t) };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const els = {}; const $ = (id) => (els[id] ||= { hidden: false, textContent: '', innerHTML: '', value: '', dataset: {}, contains: () => false, addEventListener() {}, showModal() {}, close() {}, classList: { add() {}, remove() {} } });
const window = { addEventListener() {} }; const document = { addEventListener() {}, activeElement: null };
const setInterval = () => 0; const navigator = { onLine: true };
const store = {}; const localStorage = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: (k) => { delete store[k]; } };
let user = { id: U.editor }, items = [], setlistId = null, bandId = null, openId = null; const ck = (k) => `c:${user.id}:${k}`;
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let reloads = 0; const loadSetlist = async () => { reloads++; };
const toasts = []; const say = (m) => toasts.push(m);
let renders = 0; const render = () => { renders++; }; const loadLinks = () => {}; const canEdit = () => true; const norm = (u) => { u = (u || '').trim(); return !u ? null : /^https?:\/\//i.test(u) ? u : 'https://' + u; };
const toggleClick = async () => {}; const must = async (p) => { const r = await p; if (r.error) throw r.error; return r.data; };
let confirmAnswer = true; globalThis.confirm = () => confirmAnswer;
const admin = async (sql, p = []) => (await pool.query(sql, p)).rows;
function fail(m) { console.log('FAIL:', m); process.exit(1); }
const ok = (c, m) => { if (!c) fail(m); };
async function settle() { for (let i = 0; i < 200 && flushing; i++) await sleep(5); await flush(); for (let i = 0; i < 200 && flushing; i++) await sleep(5); }
// ---- offline editing: changes are saved on the device first and sent when there is a connection
let queue = [], issues = [], flushing = false, pendingReload = false;
const qk = () => `q:${user.id}`, ik = () => `qi:${user.id}`;
const uuid = () => crypto.randomUUID();
const same = (a, b) => String(a ?? '') === String(b ?? '');
function loadQ() { try { queue = JSON.parse(localStorage.getItem(qk()) || '[]'); issues = JSON.parse(localStorage.getItem(ik()) || '[]'); } catch { queue = []; issues = []; } updateChip(); }
function saveQ() { try { localStorage.setItem(qk(), JSON.stringify(queue)); localStorage.setItem(ik(), JSON.stringify(issues)); } catch {} updateChip(); }
function enqueue(...ops) {
  const now = new Date().toISOString();
  ops.forEach((o) => queue.push({ ...o, qid: uuid(), at: now, offline: !navigator.onLine }));
  saveQ(); flush();
}
const persist = (key, v) => { try { localStorage.setItem(ck(key), JSON.stringify(v)); } catch {} };
const persistItems = () => persist('items:' + setlistId, items);
const transient = (e) => !e.code || e.code === 'PGRST301' || /jwt/i.test(e.message || '');
const verdict = (e, dupOk) => (!e ? 'done' : dupOk && e.code === '23505' ? 'done' : transient(e) ? 'retry' : { fail: e.message });
async function upd(table, vals, col, val) {
  const r = await sb.from(table).update(vals).eq(col, val).select('id');
  if (r.error) return verdict(r.error);
  return r.data.length ? 'done' : { fail: 'That item no longer exists, or you no longer have permission to change it' };
}
async function runSongEdit(op) {
  for (let tries = 0; tries < 3; tries++) {
    const cur = await sb.from('songs').select('*').eq('id', op.sid).maybeSingle();
    if (cur.error) return verdict(cur.error);
    const row = cur.data;
    if (!row || row.deleted_at) return { fail: 'This song was deleted by someone else' };
    const apply = {}, conflicts = [];
    for (const [k, v] of Object.entries(op.set)) {
      if (same(row[k], v)) continue;
      if (same(row[k], op.base[k])) apply[k] = v; else conflicts.push({ field: k, mine: v, theirs: row[k] });
    }
    if (Object.keys(apply).length) {
      const r = await sb.from('songs').update({ ...apply, change_note: op.note || (op.offline ? 'Edited offline' : null) }).eq('id', op.sid).eq('updated_at', row.updated_at).select('id');
      if (r.error) return verdict(r.error);
      if (!r.data.length) continue; // someone changed the song meanwhile: merge again
    }
    return conflicts.length ? { conflicts } : 'done';
  }
  return 'retry';
}
async function runOp(op) {
  switch (op.t) {
    case 'songNew': return verdict((await sb.from('songs').insert(op.row)).error, true);
    case 'slAdd': return verdict((await sb.from('setlist_songs').insert(op.row)).error, true);
    case 'linkAdd': return verdict((await sb.from('song_links').insert(op.row)).error, true);
    case 'slPos': return upd('setlist_songs', { position: op.position }, 'id', op.id);
    case 'slRemove': return upd('setlist_songs', { deleted_at: op.at }, 'id', op.id);
    case 'songDel': return upd('songs', { deleted_at: op.at }, 'id', op.sid);
    case 'linkDel': return upd('song_links', { deleted_at: op.at }, 'id', op.id);
    case 'song': return runSongEdit(op);
  }
  return { fail: 'Unknown change' };
}
async function flush(reload = true) {
  if (flushing || !user || !queue.length) return;
  flushing = true; let did = false;
  try {
    while (queue.length) {
      let r; try { r = await runOp(queue[0]); } catch { r = 'retry'; }
      if (r === 'retry') break; // no connection: try again later
      const op = queue.shift(); did = true;
      if (r !== 'done') issues.push({ ...op, ...r });
      saveQ();
    }
  } finally { flushing = false; saveQ(); }
  if (did && !queue.length && reload) reloadSoon();
}
function reloadSoon() { // refresh from the server, but not while someone is typing in a song
  if ($('list').contains(document.activeElement)) { pendingReload = true; return; }
  pendingReload = false; if (user && setlistId) loadSetlist();
}
function describe(o) {
  const t = `“${o.label || 'song'}”`;
  return ({ song: `Edit ${t}: ${Object.keys(o.set || {}).join(', ')}`, songNew: `New song ${t}`, songDel: `Delete ${t}`, slAdd: `Add ${t} to the setlist`, slPos: `Move ${t} in the setlist`, slRemove: `Remove ${t} from the setlist`, linkAdd: `Add a link to ${t}`, linkDel: `Remove a link from ${t}` })[o.t] || 'Change';
}
function updateChip() {
  const c = $('syncChip'); if (!c) return;
  c.hidden = !user || !(queue.length || issues.length || !navigator.onLine);
  c.textContent = issues.length ? `Check sync (${issues.length})` : queue.length ? `${queue.length} waiting` : 'Offline';
}
function drawSync() {
  $('syncState').textContent = !navigator.onLine ? 'You are offline. Changes are saved on this device and will sync when you are back online.' : queue.length ? 'Changes are waiting to sync.' : 'Everything is synced.';
  $('syncPending').innerHTML = queue.map((o) => `<li><small>${esc(describe(o))}</small></li>`).join('') || '<li><small>Nothing waiting</small></li>';
  $('syncIssues').innerHTML = issues.map((o) => (o.conflicts
    ? `<li><span>${esc(describe(o))}<br>${o.conflicts.map((c) => `<small>${esc(c.field)}: yours “${esc(String(c.mine ?? ''))}”, theirs “${esc(String(c.theirs ?? ''))}”</small>`).join('<br>')}</span><span><button data-mine="${o.qid}">Use mine</button> <button data-theirs="${o.qid}">Keep theirs</button></span></li>`
    : `<li><span>${esc(describe(o))}<br><small>Not saved: ${esc(o.fail || 'unknown problem')}</small></span><button data-dis="${o.qid}">Dismiss</button></li>`)).join('') || '<li><small>No problems</small></li>';
}
$('syncChip').onclick = () => { drawSync(); $('syncDlg').showModal(); };
$('syncClose').onclick = () => $('syncDlg').close();
$('syncNow').onclick = async () => { await flush(); drawSync(); };
$('syncIssues').onclick = (e) => {
  const d = e.target.dataset, o = issues.find((x) => x.qid === (d.mine || d.theirs || d.dis)); if (!o) return;
  issues = issues.filter((x) => x !== o);
  if (d.mine) queue.push({ t: 'song', sid: o.sid, label: o.label, qid: uuid(), at: new Date().toISOString(), offline: false, note: 'Offline edit kept over a conflicting change', base: Object.fromEntries(o.conflicts.map((c) => [c.field, c.theirs])), set: Object.fromEntries(o.conflicts.map((c) => [c.field, c.mine])) });
  saveQ(); drawSync(); if (d.mine) flush(); else reloadSoon();
};
window.addEventListener('online', () => { updateChip(); flush(); });
window.addEventListener('offline', updateChip);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') flush(); });
setInterval(() => { updateChip(); if (queue.length) flush(); }, 20000);
$('list').addEventListener('focusout', () => setTimeout(() => { if (pendingReload && !$('list').contains(document.activeElement)) reloadSoon(); }, 300));


function resetQ() { queue = []; issues = []; saveQ(); }
const band = (await admin("insert into public.bands(name, created_by) values ('Sync Band', $1) returning id", [U.owner]))[0].id; bandId = band;
await admin("insert into public.band_members(band_id,user_id,role) values ($1,$2,'owner'),($1,$3,'admin'),($1,$4,'editor'),($1,$5,'viewer')", [band, U.owner, U.admin, U.editor, U.viewer]);
const sl = (await admin("insert into public.setlists(band_id,name,created_by) values ($1,'Set',$2) returning id", [band, U.owner]))[0].id; setlistId = sl;
const count = async (t, w, p) => Number((await admin(`select count(*) from public.${t} where ${w}`, p))[0].count);

// T1: created offline, kept on the device, then synced in order
net.offline = true; navigator.onLine = false; resetQ(); reloads = 0;
const sid = crypto.randomUUID(), rid = crypto.randomUUID();
enqueue({ t: 'songNew', label: 'Offline Song', row: { id: sid, band_id: band, title: 'Offline Song', artist: 'A', bpm: 100, musical_key: 'E', created_by: U.editor } },
        { t: 'slAdd', label: 'Offline Song', row: { id: rid, band_id: band, setlist_id: sl, song_id: sid, position: 1 } });
await settle();
ok(queue.length === 2 && issues.length === 0, 'nothing should be lost or failed while offline');
ok(await count('songs', 'id=$1', [sid]) === 0, 'nothing reaches the server while offline');
ok(els.syncChip.hidden === false && els.syncChip.textContent === '2 waiting', 'chip shows 2 waiting: ' + els.syncChip.textContent);
ok(JSON.parse(store['q:' + U.editor]).length === 2, 'queue is saved on the device');
net.offline = false; navigator.onLine = true; await settle();
ok(queue.length === 0 && issues.length === 0, 'queue should drain: ' + JSON.stringify(issues));
ok(await count('songs', 'id=$1', [sid]) === 1 && await count('setlist_songs', 'id=$1 and song_id=$2', [rid, sid]) === 1, 'song and setlist entry exist with the client ids');
ok(await count('change_log', "row_id=$1 and op='INSERT'", [sid]) === 1, 'history recorded the new song');
ok(reloads >= 1, 'screen refreshed after the queue drained');
ok(els.syncChip.hidden === true, 'chip hides once synced');

// T2: replaying the same changes is harmless (idempotent)
enqueue({ t: 'songNew', label: 'Offline Song', row: { id: sid, band_id: band, title: 'Offline Song', artist: 'A', bpm: 100, musical_key: 'E', created_by: U.editor } }, { t: 'slAdd', label: 'x', row: { id: rid, band_id: band, setlist_id: sl, song_id: sid, position: 1 } });
await settle(); ok(issues.length === 0 && queue.length === 0, 'duplicates should count as done'); ok(await count('songs', 'band_id=$1', [band]) === 1, 'still one song');

// T3: a field edit, with the reason noted
navigator.onLine = false; enqueue({ t: 'song', sid, label: 'Offline Song', base: { bpm: 100 }, set: { bpm: 120 }, note: null }); navigator.onLine = true; await settle();
ok((await admin('select bpm from public.songs where id=$1', [sid]))[0].bpm === 120, 'edit applied');
ok((await admin("select reason from public.change_log where row_id=$1 and op='UPDATE' order by id desc limit 1", [sid]))[0].reason === 'Edited offline', 'history says it was edited offline');
enqueue({ t: 'song', sid, label: 'Offline Song', base: { bpm: 120 }, set: { bpm: 121 }, note: 'tempo fix' }); await settle();
ok((await admin("select reason from public.change_log where row_id=$1 and op='UPDATE' order by id desc limit 1", [sid]))[0].reason === 'tempo fix', 'typed reason kept');

// T4: someone else changed the same field: that field conflicts, the rest merges
await admin('update public.songs set bpm=130 where id=$1', [sid]);
enqueue({ t: 'song', sid, label: 'Offline Song', base: { bpm: 121, notes: '' }, set: { bpm: 140, notes: 'hello' }, note: null }); await settle();
ok(queue.length === 0 && issues.length === 1 && issues[0].conflicts.length === 1, 'one conflict expected: ' + JSON.stringify(issues));
ok(issues[0].conflicts[0].field === 'bpm' && issues[0].conflicts[0].mine === 140 && Number(issues[0].conflicts[0].theirs) === 130, 'conflict details');
let row = (await admin('select bpm, notes from public.songs where id=$1', [sid]))[0]; ok(row.bpm === 130 && row.notes === 'hello', 'theirs kept for bpm, mine merged for notes');
drawSync(); ok(els.syncIssues.innerHTML.includes('yours') && els.syncIssues.innerHTML.includes('Use mine'), 'conflict shown in the sync screen');
els.syncIssues.onclick({ target: { dataset: { mine: issues[0].qid } } }); await settle();
ok(issues.length === 0 && (await admin('select bpm from public.songs where id=$1', [sid]))[0].bpm === 140, 'use mine overwrites');
ok((await admin("select reason from public.change_log where row_id=$1 and op='UPDATE' order by id desc limit 1", [sid]))[0].reason === 'Offline edit kept over a conflicting change', 'history explains the overwrite');
await admin('update public.songs set bpm=150 where id=$1', [sid]);
enqueue({ t: 'song', sid, label: 'Offline Song', base: { bpm: 140 }, set: { bpm: 90 }, note: null }); await settle();
ok(issues.length === 1, 'second conflict'); els.syncIssues.onclick({ target: { dataset: { theirs: issues[0].qid } } });
ok(issues.length === 0 && (await admin('select bpm from public.songs where id=$1', [sid]))[0].bpm === 150, 'keep theirs leaves the server value');

// T5: a change slips in between reading and writing: merge again, no false conflict
net.hook = async () => { await admin("update public.songs set artist='Changed meanwhile' where id=$1", [sid]); };
enqueue({ t: 'song', sid, label: 'Offline Song', base: { notes: 'hello' }, set: { notes: 'n2' }, note: null }); await settle();
row = (await admin('select notes, artist from public.songs where id=$1', [sid]))[0];
ok(issues.length === 0 && row.notes === 'n2' && row.artist === 'Changed meanwhile', 'race handled: ' + JSON.stringify(row) + JSON.stringify(issues));

// T6: the song was deleted by someone else
const gone = crypto.randomUUID(); await admin("insert into public.songs(id,band_id,title,created_by,deleted_at) values ($1,$2,'Gone',$3,now())", [gone, band, U.owner]);
enqueue({ t: 'song', sid: gone, label: 'Gone', base: { notes: '' }, set: { notes: 'x' }, note: null }); await settle();
ok(issues.length === 1 && /deleted by someone else/.test(issues[0].fail), 'edit of a deleted song fails clearly'); els.syncIssues.onclick({ target: { dataset: { dis: issues[0].qid } } }); ok(issues.length === 0, 'dismiss removes it');

// T7: order, remove, delete, links
const s2 = crypto.randomUUID(), r2 = crypto.randomUUID(), r3 = crypto.randomUUID();
await admin("insert into public.songs(id,band_id,title,created_by) values ($1,$2,'Second',$3)", [s2, band, U.owner]);
await admin("insert into public.setlist_songs(id,band_id,setlist_id,song_id,position) values ($1,$2,$3,$4,2)", [r2, band, sl, s2]);
enqueue({ t: 'slPos', id: rid, position: 2, label: 'Offline Song' }, { t: 'slPos', id: r2, position: 1, label: 'Second' }); await settle();
ok((await admin('select position from public.setlist_songs where id=$1', [rid]))[0].position === 2 && (await admin('select position from public.setlist_songs where id=$1', [r2]))[0].position === 1, 'positions swapped');
enqueue({ t: 'slRemove', id: r2, label: 'Second' }); await settle(); ok((await admin('select deleted_at from public.setlist_songs where id=$1', [r2]))[0].deleted_at !== null, 'removed from setlist');
const lid = crypto.randomUUID(); enqueue({ t: 'linkAdd', label: 'Offline Song', row: { id: lid, band_id: band, song_id: sid, kind: 'tab', label: 'Tab', url: 'https://example.com/t', added_by: U.editor } }); await settle();
ok(await count('song_links', 'id=$1 and deleted_at is null', [lid]) === 1, 'link added'); enqueue({ t: 'linkDel', id: lid, label: 'Offline Song' }); await settle(); ok(await count('song_links', 'id=$1 and deleted_at is null', [lid]) === 0, 'link removed');
enqueue({ t: 'songDel', sid: s2, label: 'Second' }); await settle(); ok((await admin('select deleted_at from public.songs where id=$1', [s2]))[0].deleted_at !== null, 'song deleted');
ok(issues.length === 0, 'no issues in T7: ' + JSON.stringify(issues));

// T8: a viewer's queued changes are refused clearly and do not block the queue
net.uid = U.viewer; user = { id: U.viewer }; resetQ();
const vs = crypto.randomUUID();
enqueue({ t: 'songNew', label: 'Viewer Song', row: { id: vs, band_id: band, title: 'Viewer Song', created_by: U.viewer } }, { t: 'slAdd', label: 'Viewer Song', row: { id: crypto.randomUUID(), band_id: band, setlist_id: sl, song_id: vs, position: 9 } }, { t: 'slPos', id: rid, position: 7, label: 'Offline Song' });
await settle();
ok(queue.length === 0 && issues.length === 3 && issues.every((x) => x.fail), 'viewer changes refused: ' + JSON.stringify(issues));
ok(await count('songs', 'id=$1', [vs]) === 0 && (await admin('select position from public.setlist_songs where id=$1', [rid]))[0].position === 2, 'nothing reached the server');
drawSync(); ok(els.syncIssues.innerHTML.includes('Not saved') && els.syncIssues.innerHTML.includes('Dismiss') && els.syncChip.textContent === 'Check sync (3)', 'issues visible');
net.uid = U.editor; user = { id: U.editor }; resetQ();

// T9: connection drops part-way through: order kept, the rest waits
const a1 = crypto.randomUUID(), a2 = crypto.randomUUID(), a3 = crypto.randomUUID();
await admin("insert into public.songs(id,band_id,title,created_by) values ($1,$4,'A1',$5),($2,$4,'A2',$5),($3,$4,'A3',$5)", [a1, a2, a3, band, U.owner]);
net.count = 0; net.offlineAfter = 2; // a song edit is two database calls: read then write
enqueue({ t: 'song', sid: a1, label: 'A1', base: { notes: '' }, set: { notes: 'one' }, note: null }, { t: 'song', sid: a2, label: 'A2', base: { notes: '' }, set: { notes: 'two' }, note: null }, { t: 'song', sid: a3, label: 'A3', base: { notes: '' }, set: { notes: 'three' }, note: null });
await settle();
ok(queue.length >= 1 && queue[0].sid !== a1 && issues.length === 0, 'drop mid-way keeps the rest in order: ' + queue.map((q) => q.label));
ok((await admin('select notes from public.songs where id=$1', [a3]))[0].notes === '', 'later changes have not jumped ahead');
net.offlineAfter = null; net.offline = false; await settle();
ok(queue.length === 0 && (await admin('select notes from public.songs where id=$1', [a3]))[0].notes === 'three' && (await admin('select notes from public.songs where id=$1', [a1]))[0].notes === 'one', 'all applied once the connection returns');

// T10: how errors are classified
ok(transient({ code: '', message: 'TypeError: Failed to fetch' }) && transient({ code: 'PGRST301', message: 'x' }) && transient({ code: 'XX', message: 'JWT expired' }) && !transient({ code: '42501', message: 'denied' }), 'transient rules');
ok(verdict(null) === 'done' && verdict({ code: '23505', message: 'dup' }, true) === 'done' && verdict({ code: '23505', message: 'dup' }, false).fail === 'dup' && verdict({ code: '', message: 'net' }) === 'retry', 'verdict rules');

// T11: the queue survives a restart
net.offline = true; resetQ(); enqueue({ t: 'songDel', sid: a1, label: 'A1' }); await settle(); queue = []; issues = []; loadQ(); ok(queue.length === 1 && queue[0].t === 'songDel', 'queue restored from the device'); net.offline = false; await settle(); ok(queue.length === 0, 'and then synced');
console.log('sync engine checks passed (against a real Postgres with row-level security)');
