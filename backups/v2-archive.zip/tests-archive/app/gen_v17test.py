import re,subprocess
src=open('/tmp/v17.mjs',encoding='utf-8').read()
def between(a,b):
    i=src.index(a); j=src.index(b,i); return src[i:j]
slug=between("// ---- band link","// ---- access levels and band members")
dl=re.search(r"const CONF = .*?\n\}\n",src,re.S).group(0)
sfget=re.search(r"    else if \(a === 'sfget'\) \{.*?\n    \}\n",src,re.S).group(0)
lookup=re.search(r"    else if \(a === 'lookup'\) \{.*?\n    \}\n    else if \(a === 'sfget'\)",src,re.S).group(0)
pre=r"""
const esc=(s)=>String(s??'').replace(/[&<>"']/g,(c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const els={}; const mk=()=>({hidden:false,textContent:'',innerHTML:'',value:'',disabled:false,dataset:{}});
const $=(id)=>(els[id] ||= mk());
const toasts=[]; const say=(m)=>toasts.push(m);
const loc={origin:'https://timlawless.github.io',pathname:'/setlists/',search:'',hash:''}; const location=new Proxy(loc,{get:(t,k)=>t[k]});
const hist=[]; const history={replaceState:(a,b,url)=>{hist.push(url); loc.hash=url.startsWith('#')?url:''}};
const window={listeners:{},addEventListener(n,f){this.listeners[n]=f}};
let bandRows=[], bandId=null, user={id:'U'}, loads=0, gigClosed=0; const loadBand=async()=>{loads++}; const closeGig=()=>{gigClosed++};
const store={}; const localStorage={getItem:(k)=>(k in store?store[k]:null),setItem:(k,v)=>{store[k]=String(v)},removeItem:(k)=>{delete store[k]}};
let dbCalls=[]; let dbAnswer={data:[{id:'B1'}],error:null};
const sb={from:()=>{const q={t:'bands',steps:[]}; for(const m of ['update','eq','select']) q[m]=(...a)=>{q.steps.push([m,...a]);return q}; q.then=(res)=>{dbCalls.push(q);res(dbAnswer)}; return q}};
const navigator={clipboard:{writeText:async()=>{throw new Error('blocked')}}}; const prompts=[]; globalThis.prompt=(m,t)=>{prompts.push(t)};
let matches=[], cands=[];
function fail(m){console.log('FAIL:',m);process.exit(1)} const ok=(c,m)=>{if(!c)fail(m)};
"""
body=r"""
// ---- hash parsing
loc.hash='#WC'; ok(hashSlug()==='wc','upper case hash folded'); loc.hash='#%20wc%20'; ok(hashSlug()==='wc','encoded spaces trimmed'); loc.hash='#%E0%A4%A'; ok(hashSlug()==='','bad encoding ignored'); loc.hash=''; ok(hashSlug()==='','empty');
// ---- choosing a band from the link
bandRows=[{bands:{id:'B1',name:'Weaponized Conch',slug:'wc'}},{bands:{id:'B2',name:'Other',slug:null}}]; bandId='B2';
loc.hash='#wc'; ok(pickBandFromHash()===true&&els.band.value==='B1'&&store.band==='B1','a member opens the band from its link');
loc.hash=''; toasts.length=0; ok(pickBandFromHash()===false&&toasts.length===0,'no link, no change');
loc.hash='#nothere'; hist.length=0; ok(pickBandFromHash()===false&&toasts.at(-1).includes('not a member')&&toasts.at(-1).includes('#nothere'),'unknown or other band: same message, nothing revealed');
ok(hist.at(-1)==='/setlists/'&&loc.hash==='','bad link is cleared from the address bar so the message is not repeated');
// ---- keeping the address bar in step with the open band
bandId='B1'; hist.length=0; syncHash(); ok(hist.at(-1)==='#wc','open band with a link shows it'); bandId='B2'; syncHash(); ok(hist.at(-1)==='/setlists/','band without a link clears it');
// ---- the settings panel
bandId='B1'; drawSlug(); ok(els.slugIn.value==='wc'&&els.slugPrev.textContent==='https://timlawless.github.io/setlists/#wc'&&els.linkRow.hidden===false&&els.linkTxt.textContent.endsWith('#wc'),'preview and copy row');
bandId='B2'; drawSlug(); ok(els.slugIn.value===''&&/No link yet/.test(els.slugPrev.textContent)&&els.linkRow.hidden===true,'empty state');
// ---- saving an ending
const save=async(v)=>{els.slugIn.value=v; dbCalls=[]; toasts.length=0; await els.slugSave.onclick()};
bandId='B1';
for(const bad of ['a','-wc','wc_x','wc band','WC!','x'.repeat(31)]){ await save(bad); ok(dbCalls.length===0&&/lower-case letters/.test(toasts.at(-1)),'refused before any call: '+bad); }
for(const r of ['join','invite','admin','null']){ await save(r); ok(dbCalls.length===0&&/kept for the app/.test(toasts.at(-1)),'reserved: '+r); }
dbAnswer={data:[{id:'B1'}],error:null}; await save('  #Weaponized-C  ');
ok(dbCalls.length===1&&JSON.stringify(dbCalls[0].steps).includes('"slug":"weaponized-c"')&&bandRows[0].bands.slug==='weaponized-c'&&hist.at(-1)==='#weaponized-c'&&toasts.at(-1)==='Band link saved','saved lower-cased with # stripped, shown at once');
await save('wc'); ok(bandRows[0].bands.slug==='wc','changed back');
dbAnswer={data:null,error:{code:'23505',message:'duplicate key'}}; await save('taken'); ok(/already taken/.test(toasts.at(-1))&&bandRows[0].bands.slug==='wc','taken ending explained, nothing changed');
dbAnswer={data:null,error:{code:'',message:'TypeError: Failed to fetch'}}; await save('xy'); ok(/offline/.test(toasts.at(-1)),'offline message');
dbAnswer={data:null,error:{code:'42501',message:'denied'}}; await save('xy'); ok(/Error: denied/.test(toasts.at(-1)),'other errors shown');
dbAnswer={data:[],error:null}; await save('xy'); ok(/Only owners and admins/.test(toasts.at(-1))&&bandRows[0].bands.slug==='wc','no row changed means no permission');
dbAnswer={data:[{id:'B1'}],error:null}; await save(''); ok(JSON.stringify(dbCalls[0].steps).includes('"slug":null')&&bandRows[0].bands.slug===null&&toasts.at(-1)==='Band link removed','clearing sends null');
bandRows[0].bands.slug='wc';
// ---- copy
await els.slugCopy.onclick(); ok(prompts.at(-1)==='https://timlawless.github.io/setlists/#wc','falls back to a prompt when the clipboard is blocked');
let copied=''; navigator.clipboard.writeText=async(t)=>{copied=t}; toasts.length=0; await els.linkCopy.onclick(); ok(copied.endsWith('/setlists/#wc')&&toasts.at(-1)==='Link copied','clipboard used when allowed');
// ---- someone edits the address by hand
bandId='B2'; loads=0; loc.hash='#wc'; window.listeners.hashchange(); ok(loads===1&&gigClosed===1&&els.band.value==='B1','address change switches band');
bandId='B1'; loads=0; window.listeners.hashchange(); ok(loads===0,'same band: nothing to do'); loc.hash=''; window.listeners.hashchange(); ok(loads===0,'cleared hash ignored'); user=null; loc.hash='#wc'; bandId='B2'; window.listeners.hashchange(); ok(loads===0,'signed out: ignored'); user={id:'U'};
console.log('band link checks passed');
// ---- the lookup list
"""+dl+r"""
const ul=mk();
matches=[{artist:'Black Eyed Peas',title:'I Gotta Feeling',tempo:128,key_of:'Em',time_sig:'',source:'Song Finder',confidence:'high'}];
cands=[{id:'sf:USAAA0000001',artist:'The <b>Wanderers</b>',title:'I Gotta Feeling',album:'Old Roads',year:'1969'},{id:'sf:USAAA0000002',artist:'Z',title:'T',album:'',year:''}];
drawLookup(ul); let h=ul.innerHTML;
ok(h.includes('128 bpm · Em · Song Finder · confidence: high')&&h.includes('data-a="usematch"'),'analysed match with Use');
ok((h.match(/data-a="sfget"/g)||[]).length===2&&h.includes('Old Roads · 1969')&&h.includes('Song Finder</small>')&&h.includes('&lt;b&gt;Wanderers'),'candidates with Get tempo and key, escaped');
ok(h.includes('Pick the recording that matches')&&h.includes('your own values always win'),'guidance shown');
matches=[]; cands=[]; drawLookup(ul); ok(ul.innerHTML.includes('No matches'),'empty'); matches=[{artist:'A',title:'T',tempo:100,key_of:'C',time_sig:'4/4',source:'GetSongBPM',confidence:'medium'}]; drawLookup(ul); ok(!ul.innerHTML.includes('Pick the recording')&&ul.innerHTML.includes('100 bpm · C · 4/4 · GetSongBPM'),'GetSongBPM results without candidates');
// ---- the Get tempo and key button
let invokes=[]; let answer={data:{results:[{id:'sf:USAAA0000001',title:'I Gotta Feeling',artist:'',tempo:128,key_of:'Em',time_sig:'',source:'Song Finder',confidence:'check',note:'A second source reads 64 BPM.'}]},error:null};
sb.functions={invoke:async(n,o)=>{invokes.push([n,o]);return answer}};
async function sfgetRun(k, btn){ const a='sfget', b=btn, art={querySelector:()=>ul}; """+sfget.replace("    else if (a === 'sfget')","    if (a === 'sfget')",1)+r""" }
matches=[]; cands=[{id:'sf:USAAA0000001',artist:'Black Eyed Peas',title:'I Gotta Feeling',album:'The E.N.D.',year:'2009'},{id:'sf:USAAA0000002',artist:'Z',title:'T',album:'',year:''}];
let btn={dataset:{k:'0'},disabled:false,textContent:'Get tempo and key'}; await sfgetRun(0,btn);
ok(invokes[0][0]==='lookup-song'&&invokes[0][1].body.isrc==='sf:USAAA0000001','asks for that one recording');
ok(matches.length===1&&matches[0].artist==='Black Eyed Peas'&&matches[0].title==='I Gotta Feeling'&&cands.length===1&&cands[0].artist==='Z','result keeps the candidate name and artist; candidate leaves the list');
ok(ul.innerHTML.includes('check this tempo')&&ul.innerHTML.includes('A second source reads 64 BPM.')&&ul.innerHTML.includes('data-a="usematch"'),'now shown with Use and the tempo warning');
answer={data:{results:[],note:'No tempo and key analysis is available for that recording.'},error:null}; btn={dataset:{k:'0'},disabled:false,textContent:'Get tempo and key'}; toasts.length=0; await sfgetRun(0,btn);
ok(btn.textContent==='Not available'&&btn.disabled===false&&/No tempo and key/.test(toasts.at(-1))&&cands.length===1,'no analysis: candidate stays, clear message');
answer={data:null,error:{message:'x',context:{json:async()=>({error:'Song Finder is busy. Try again in a few seconds.'})}}}; btn={dataset:{k:'0'},disabled:false,textContent:'Get tempo and key'}; toasts.length=0; await sfgetRun(0,btn);
ok(/busy/.test(toasts.at(-1))&&btn.disabled===false&&btn.textContent==='Get tempo and key','busy: button restored so it can be tried again');
console.log('two-step lookup checks passed');
"""
open('/tmp/v17test.mjs','w').write(pre+slug+body)
r=subprocess.run(['node','/tmp/v17test.mjs'],capture_output=True,text=True); print(r.stdout,r.stderr[:1800])
